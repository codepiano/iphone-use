import argparse,http.server,json,urllib.request,urllib.error
p=argparse.ArgumentParser();p.add_argument('--port',type=int,required=True);p.add_argument('--upstream',required=True);p.add_argument('--out',required=True);a=p.parse_args()
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
class Handler(http.server.BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_GET(self):self.forward()
 def do_POST(self):self.forward()
 def do_DELETE(self):self.forward()
 def forward(self):
  size=int(self.headers.get('Content-Length','0'));assert 0<=size<=1000000
  data=self.rfile.read(size) if size else None
  headers={k:v for k,v in self.headers.items() if k.lower() not in ['host','connection','content-length']}
  req=urllib.request.Request(a.upstream+self.path,data=data,headers=headers,method=self.command)
  try:r=opener.open(req,timeout=30)
  except urllib.error.HTTPError as e:r=e
  body=r.read();meta={k:v for k,v in r.headers.items() if k.lower().startswith('x-ipu-')}
  with open(a.out,'a') as f:f.write(json.dumps({'method':self.command,'path':self.path,'status':r.code,'headers':meta})+'\n')
  self.send_response(r.code)
  self.send_header('Content-Type',r.headers.get('Content-Type','application/json'));self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
http.server.ThreadingHTTPServer(('127.0.0.1',a.port),Handler).serve_forever()
