from pathlib import Path
import json,hashlib
p=Path(__file__).resolve().parent
records={};groups={}
for d in sorted(p.iterdir()):
 if not (len(d.name)>2 and d.name[:2].isdigit() and d.name[2]=='-'):continue
 if not d.is_dir():continue
 v=json.loads((d/'results.json').read_text());assert v.get('experiment_finished') and not v.get('error') and not v['cleanup_errors'],d
 groups[d.name]=v
 for r in v['cases']:
  assert r['trial'] not in records;records[r['trial']]=r
assert len(records)==16,len(records)
h=lambda s:hashlib.sha256(s.encode()).hexdigest()
for name,r in records.items():
 a=r['after'];before=r['before'];fields=a['fields'];b=r['reply']['result'].get('structuredContent',{})
 assert a['foreground_active'] and a['trial']==name
 for key in ['multi','secure']:assert fields[key]==before['fields'][key],(name,key)
 if name=='unsupported-old':
  assert b.get('error')=='replacement_focus_recovery_unsupported' and b.get('outcome')=='not_sent' and b.get('retry_safe') is True
  assert fields==before['fields'] and not any(a['events'].values()) and not a['advance_triggered']
 elif name=='strict-advance':
  assert a['advance_triggered'] and fields['a']['sha256']==h('') and fields['b']==before['fields']['b'] and a['a_touch_starts']==a['a_touches_at_clear']
  assert b.get('outcome')=='unknown' and not r['requested_text_match']
 elif name in ['normal-opt-in','unfocused-b-opt-in','advance-opt-in-1','advance-opt-in-2','empty-clear-opt-in']:
  assert r['requested_text_match'] and r['other_fields_unchanged'] and b.get('ok') is True
  if name.startswith('advance-opt-in'):
   assert a['advance_triggered'] and a['focus']=='a' and a['a_touch_starts']-a['a_touches_at_clear']==1
  if name=='empty-clear-opt-in':assert a['advance_triggered'] and a['focus']=='b' and a['a_touch_starts']==a['a_touches_at_clear']
 elif name in ['refilled-before-focus','disabled-original','hidden-original','secure-conversion','covered-original']:
  assert a['advance_triggered'] and fields['b']==before['fields']['b'] and a['a_touch_starts']==a['a_touches_at_clear']
  assert not r['requested_text_match'] and b.get('outcome')=='unknown' and b.get('retry_safe') is False
  if name=='refilled-before-focus':assert fields['a']['sha256']==h('App restored draft')
  else:assert fields['a']['sha256']==h('')
  if name=='disabled-original':assert a['a_enabled'] is False
  if name=='hidden-original':assert a['a_hidden'] is True
  if name=='secure-conversion':assert a['a_secure'] is True
  if name=='covered-original':assert a['overlay_present'] and a['overlay_actions']==0
 elif name=='refilled-on-focus':
  assert a['advance_triggered'] and fields['a']['sha256']==h('App refocus draft') and fields['b']==before['fields']['b']
  assert a['a_touch_starts']-a['a_touches_at_clear']==1 and not r['requested_text_match'] and b.get('outcome')=='unknown'
 elif name in ['failed-selection','partial-selection']:
  assert fields==before['fields'] and not any(a['events'].values()) and 1<=a['selection_commands']<=2 and not a['advance_triggered']
 elif name=='late-focus':
  assert a['shift_trigger_length']==20 and fields['a']['characters']==20 and fields['b']['characters']==180 and a['a_touch_starts']==0
  assert not r['requested_text_match'] and b.get('outcome')=='unknown'
 else:raise AssertionError(name)
positive=groups['02-positive']['cases'];profile=[json.loads(x) for x in (p/'02-positive/header-profile.jsonl').read_text().splitlines()]
prefixes=[x for x in profile if x['method']=='POST' and '/replace' in x['path']];assert len(prefixes)==len(positive)
for r,entry in zip(positive,prefixes):
 headers=entry['headers']
 if r['trial'].startswith('advance-opt-in'):assert headers.get('X-IPU-Clear-Focus-Restored')=='1'
 elif r['trial']=='empty-clear-opt-in':assert headers.get('X-IPU-Clear-Original-Verified')=='1' and headers.get('X-IPU-Clear-Focus-Restored')!='1'
 else:assert headers.get('X-IPU-Clear-Focus-Restored')!='1'
covered=[json.loads(x) for x in (p/'07-covered/header-profile.jsonl').read_text().splitlines()]
assert any(int(x['headers'].get('X-IPU-RecoveryScene-Calls','0'))>=1 for x in covered)
summary={'scope':'One physical iPhone17ProMax/iOS27.2 local-network lane; explicit opt-in selected-field recovery; not mid-input isolation, real-model or release acceptance','base_revision':'72f69ee06e7ec578f5908feeab6b2ed2890e365d','final_native_patch':'recovery-candidate-v8','checked_records':16,'ordinary_500_character_replacements':'4/4 exact (normal A, initially unfocused B, two clear-time handoffs)','clear_time_recovery':'2/2 exact with one App-recorded restoration touch each','empty_clear':'exact, next field focus retained, zero restoration touches','old_runner':'unsupported/not_sent; unchanged field hashes and zero edits','covered_original':'injected overlay present, zero button actions/field touches; complete-scene guard ran','app_refills_original':'new content preserved before/after recovery tap; no delete/text replay','default_strict_policy':'stops after clear-time focus loss; next field unchanged','mid_input_focus_limit':'still A20/B180; full request fails; option never rebinds after partial text','cleanup_errors':[]}
(p/'final-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
