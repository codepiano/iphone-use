from pathlib import Path
import os,subprocess,json,shutil
p=Path(__file__).resolve().parent
cohorts=[
 ('00-old-unsupported',True,'unsupported-old'),
 ('01-strict-default',False,'strict-advance'),
 ('02-positive',False,'normal-opt-in,unfocused-b-opt-in,advance-opt-in-1,advance-opt-in-2,empty-clear-opt-in'),
 ('03-refilled-before-focus',False,'refilled-before-focus'),
 ('04-disabled',False,'disabled-original'),
 ('05-hidden',False,'hidden-original'),
 ('06-secure-conversion',False,'secure-conversion'),
 ('07-covered',False,'covered-original'),
 ('08-refilled-on-focus',False,'refilled-on-focus'),
 ('09-failed-selection',False,'failed-selection'),
 ('10-partial-selection',False,'partial-selection'),
 ('11-late-focus',False,'late-focus'),
]
for label,old,cases in cohorts:
 env=dict(os.environ);env['PHYSICAL_CASES']=cases
 if old:env['PHYSICAL_OLD']='1'
 else:env.pop('PHYSICAL_OLD',None)
 (p/'header-profile.jsonl').unlink(missing_ok=True)
 with (p/'controller.log').open('w') as log:r=subprocess.run(['python3',str(p/'run-recovery.py')],env=env,stdout=log,stderr=log)
 dest=p/label;dest.mkdir(mode=0o700)
 for name in ['results.json','controller.log','runner.log','relay.log','daemon.log','mcp.log','header-profile.jsonl','run-recovery.py']:
  f=p/name
  if f.exists():shutil.copyfile(f,dest/name)
 v=json.loads((p/'results.json').read_text());actual=[x['trial'] for x in v['cases']]
 print(label,'cases',actual,'exact',[x['requested_text_match'] for x in v['cases']],'error',v.get('error'),'cleanup',v['cleanup_errors'],flush=True)
 if r.returncode or v.get('error') or v['cleanup_errors'] or actual!=cases.split(','):raise SystemExit(1)
 if label=='02-positive' and not all(x['requested_text_match'] and x['other_fields_unchanged'] for x in v['cases']):raise SystemExit(2)
