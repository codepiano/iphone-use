from pathlib import Path
import os,sys,subprocess,json,time,signal,urllib.request,urllib.error,importlib.util,hashlib,traceback,plistlib
ROOT=Path('/tmp/iphone-use-runner-input-target-guard');OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from runner_auth import authorization
spec=importlib.util.spec_from_file_location('paired',ROOT/'scripts/compare-native-wda-simulator.py');paired=importlib.util.module_from_spec(spec);spec.loader.exec_module(paired)
p=json.loads((OUT/'private.json').read_text());udid=p['udid'];bundle=p['fixture_id'];token=p['token']
env={k:v for k,v in os.environ.items() if not k.startswith(('IPHONE_USE_','PHONE_REMOTE_','IPU_','TEST_RUNNER_','SIMCTL_CHILD_'))}
env.update(DEVELOPER_DIR='/Applications/Xcode-27.2-beta2.app/Contents/Developer',DO_NOT_TRACK='1',IPHONE_USE_ANALYTICS='0')
processes=[];peer=None;result={'scope':'Selected-field clear recovery on one physical iPhone; explicit policy, not mid-input isolation or overall superiority','candidate':'72f69ee plus recovery-candidate-v8 patch','cases':[],'cleanup_errors':[]}
def save(): (OUT/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
def command(*args,timeout=65):
 r=subprocess.run(args,env=env,capture_output=True,text=True,timeout=timeout)
 if r.returncode:raise RuntimeError('command failed: '+str(args[:5])+' '+r.stderr[-1500:]+' '+r.stdout[-1200:])
 return r.stdout
def start(name,args,e):
 with (OUT/(name+'.log')).open('w') as log: proc=subprocess.Popen(args,env=e,stdout=log,stderr=log,start_new_session=True)
 processes.append((name,proc));return proc
def api(path,body=None,runner=False):
 data=json.dumps(body).encode() if body is not None else None;method='POST' if data else 'GET'
 port=p['relay_port'] if runner else p['daemon_port']
 auth=authorization(token,method,path,data or b'') if runner else 'Bearer '+token
 req=urllib.request.Request(f'http://127.0.0.1:{port}'+path,data=data,headers={'Authorization':auth,'Content-Type':'application/json','X-Phone-Control':'1','X-Phone-Owner':'physical-e73-acceptance'})
 with urllib.request.urlopen(req,timeout=5) as r:return json.load(r)
def receipt(trial):
 target=OUT/('receipt-'+trial+'.json');target.unlink(missing_ok=True)
 command('xcrun','devicectl','device','copy','from','--device',udid,'--domain-type','appDataContainer','--domain-identifier',bundle,'--source','Documents/paired-state.json','--destination',str(target),'--timeout','20')
 return json.loads(target.read_text())
def reset(trial,seed='short',shift=False,secure=False,advance=False,clear_fault=''):
 f=OUT/'paired-reset.json';f.write_text(json.dumps({'trial':trial,'seed':seed,'shift':shift,'secure':secure,'advance':advance,'clear_fault':clear_fault}))
 command('xcrun','devicectl','device','copy','to','--device',udid,'--domain-type','appDataContainer','--domain-identifier',bundle,'--source',str(f),'--destination','Documents/paired-reset.json','--timeout','20')
 deadline=time.monotonic()+25
 while True:
  s=receipt(trial)
  if s.get('trial')==trial and s.get('foreground_active') and s.get('initial_focus_established') and s.get('keyboard_did_show') and s.get('focus')==('secure' if secure else 'a'):return s
  if time.monotonic()>deadline:raise RuntimeError('fixture reset did not converge: '+str(s))
  time.sleep(.3)
def call(name,args):
 reply=peer.request('tools/call',{'name':name,'arguments':args},timeout=100)
 return reply,paired.payload(reply)[2]
def observation():
 reply,body=call('phone_elements',{})
 if reply.get('result',{}).get('isError'):raise RuntimeError('observation refused')
 rows=body.get('elements',[])
 indexes={x.get('identifier'):i for i,x in enumerate(rows)}
 assert all(k in indexes for k in ['field-a','field-b','field-multiline','field-secure']),str(body)[:1200]
 return body['snapshot'],indexes
try:
 # Respect the existing daemon's current owner before starting any phone UI work.
 old=plistlib.loads((Path.home()/'Library/LaunchAgents/com.leeguoo.iphone-use.plist').read_bytes()).get('EnvironmentVariables',{})
 auth=old.get('IPHONE_USE_AGENT_TOKEN') or old.get('IPHONE_USE_PASSWORD')
 req=urllib.request.Request('http://127.0.0.1:44321/agent/status',headers={'Authorization':'Bearer '+auth})
 with urllib.request.urlopen(req,timeout=5) as r:status=json.load(r)
 assert status.get('owner') is None and not status.get('drivable'),'existing service active: do not take over'
 command('xcrun','devicectl','device','install','app','--device',udid,str(OUT/'PhysicalFixture.app'),'--timeout','60')
 result['fixture_installed']=True;save()
 p['profile_proxy_port']=paired.port()
 relay=start('relay',[str(OUT/'bin/iphone-use'),'relay','--udid',udid,'--listen','127.0.0.1:'+str(p['relay_port']),'--device-port',str(p['runner_port'])],env)
 proxy=start('header-profile',['python3',str(OUT/'header-profile-proxy.py'),'--port',str(p['profile_proxy_port']),'--upstream','http://127.0.0.1:'+str(p['relay_port']),'--out',str(OUT/'header-profile.jsonl')],env)
 re=dict(env);re.update(TEST_RUNNER_IPU_RUNNER_PORT=str(p['runner_port']),TEST_RUNNER_IPU_RUNNER_TOKEN=token,TEST_RUNNER_IPU_RUNNER_MJPEG_PORT='0',TEST_RUNNER_IPU_DAEMON_PORT='0')
 runner=start('runner',['xcodebuild','test-without-building','-xctestrun',str(OUT/('old-private.xctestrun' if os.environ.get('PHYSICAL_OLD')=='1' else 'physical-private.xctestrun')),'-destination','id='+udid,'-only-testing:IPhoneUseRunnerUITests/RunnerTests/testServe','-parallel-testing-enabled','NO'],re)
 deadline=time.monotonic()+200
 while True:
  try:
   if api('/status',runner=True).get('value',{}).get('ready'):break
  except Exception:pass
  assert runner.poll() is None and relay.poll() is None and time.monotonic()<deadline,'isolated runner readiness failed; inspect private logs'
  time.sleep(1)
 result['runner_ready']=True;save()
 private=OUT/'state';runtime=OUT/'runtime';private.mkdir(mode=0o700,exist_ok=True);runtime.mkdir(mode=0o700,exist_ok=True)
 (private/'runner-token').write_text(token);(private/'runner-token').chmod(0o600)
 de=dict(env);de.update(IPHONE_USE_HOST='127.0.0.1',IPHONE_USE_PORT=str(p['daemon_port']),IPHONE_USE_UDID=udid,IPHONE_USE_INSTANCE='physical-e73',TMPDIR=str(runtime),IPHONE_USE_STATE_DIR=str(private),IPHONE_USE_RUNNER_URL=f'http://127.0.0.1:{p["profile_proxy_port"]}',IPHONE_USE_RUNNER_MJPEG_URL=f'http://127.0.0.1:{p["relay_port"]}',IPHONE_USE_RUNNER_MANAGED='0',IPHONE_USE_AGENT_TOKEN=token,IPHONE_USE_PASSWORD='fixture-'+token,IPHONE_USE_AUTO_FOCUS='0',IPHONE_USE_IDLE_RELEASE_SECS='0',IPHONE_USE_FLOWS_NO_AUTO_UPDATE='1')
 daemon=start('daemon',[str(OUT/'bin/iphone-use'),'serve'],de)
 deadline=time.monotonic()+45
 while True:
  try:
   status=api('/agent/status')
   if status.get('drivable'):break
  except Exception:pass
  assert daemon.poll() is None and time.monotonic()<deadline,'candidate daemon not drivable'
  time.sleep(.5)
 result['daemon_drivable']=True;save()
 pe=dict(env);pe.update(IPHONE_USE_URL=f'http://127.0.0.1:{p["daemon_port"]}',IPHONE_USE_TOKEN=token,IPHONE_USE_OWNER='physical-e73-acceptance',IPHONE_USE_MCP_PREWARM='0',IPHONE_USE_MCP_STRUCTURED='full',IPHONE_USE_STATE_DIR=str(private))
 peer=paired.Peer([str(OUT/'bin/iphone-use-mcp')],pe,OUT/'mcp.log')
 command('xcrun','devicectl','device','process','launch','--device',udid,bundle,'--','--trial','physical-initial','--seed','short')
 call('phone_status',{})
 cases=[
  ('unsupported-old','short','field-a',500,True,'',True,False),
  ('strict-advance','short','field-a',500,False,'',True,False),
  ('normal-opt-in','short','field-a',500,True,'',False,False),
  ('unfocused-b-opt-in','short','field-b',500,True,'',True,False),
  ('advance-opt-in-1','short','field-a',500,True,'',True,False),
  ('advance-opt-in-2','short','field-a',500,True,'',True,False),
  ('empty-clear-opt-in','long','field-a',0,True,'',True,False),
  ('refilled-before-focus','short','field-a',500,True,'repopulate',True,False),
  ('disabled-original','short','field-a',500,True,'disable',True,False),
  ('hidden-original','short','field-a',500,True,'hide',True,False),
  ('secure-conversion','short','field-a',500,True,'secure',True,False),
  ('covered-original','short','field-a',500,True,'overlay',True,False),
  ('refilled-on-focus','short','field-a',500,True,'refocus-repopulate',True,False),
  ('failed-selection','ignore-all','field-a',500,True,'',False,False),
  ('partial-selection','selection-partial','field-a',500,True,'',False,False),
  ('late-focus','short','field-a',500,True,'',False,True),
 ]
 selected=os.environ.get('PHYSICAL_CASES','').split(',')
 assert selected!=[''] and all(name in [c[0] for c in cases] for name in selected),'explicit owned cases required'
 cases=sorted([c for c in cases if c[0] in selected],key=lambda c:selected.index(c[0]))
 result['runner_lane']='old' if os.environ.get('PHYSICAL_OLD')=='1' else 'candidate'
 for trial,seed,target,length,recover,fault,advance,shift in cases:
  before=reset(trial,seed,advance=advance,shift=shift,clear_fault=fault)
  active=api('/wda/activeAppInfo',runner=True).get('value',{})
  assert active.get('bundleId')==bundle and active.get('pid')==before['pid'],'foreground mismatch before task'
  snap,indexes=observation()
  text=('shift-focus-test-'+'字'*483) if shift else '字'*length
  args={'element':indexes[target],'snapshot':snap,'value':text,'observe':False}
  if recover:args['recover_focus_after_clear']=True
  started=time.monotonic();reply,body=call('phone_set_value',args)
  response_ms=round((time.monotonic()-started)*1000,3)
  time.sleep(.5);after=receipt(trial)
  key='b' if target=='field-b' else 'a'
  record={'trial':trial,'before':before,'arguments':args,'reply':reply,'after':after,'response_ms_diagnostic':response_ms,
   'requested_text_match':after['fields'][key]['sha256']==hashlib.sha256(text.encode()).hexdigest(),
   'other_fields_unchanged':all(after['fields'][k]==before['fields'][k] for k in before['fields'] if k!=key)}
  result['cases'].append(record);save();print('finished',trial,'exact',record['requested_text_match'],flush=True)
  if body.get('outcome')=='unknown' or body.get('retry_safe') is False:
   result['stopped_after_unknown_or_unsafe_retry']=trial;save();break
 result['experiment_finished']=True
except BaseException as e:
 result['error']=str(e);result['traceback']=traceback.format_exc();save();print(type(e).__name__,str(e),flush=True)
finally:
 if peer:
  try:
   if peer.pending is None:call('phone_release_owner',{})
   peer.close()
  except Exception as e:result['cleanup_errors'].append('peer: '+str(e))
 for name,process in reversed(processes):
  try:paired.stop(process)
  except Exception as e:result['cleanup_errors'].append(name+': '+str(e))
 save()
