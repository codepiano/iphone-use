from pathlib import Path
BASE=Path(__file__).resolve().parent
# Reuse only helper definitions from the executed native fixture driver, not its actions.
source=(BASE/'run-physical.py').read_text();exec(compile(source[:source.index('\ntry:\n')],str(BASE/'run-physical.py'),'exec'))
import secrets
REFERENCE=Path('/tmp/iphone-use-reference-compare-20261025')
assert command('git','-C',str(REFERENCE),'rev-parse','HEAD').strip()=='3ce9c080534e89fab91a237bf1c53a4a7e9d80a7'
assert not command('git','-C',str(REFERENCE),'status','--porcelain').strip()
PAIR=BASE/'paired';PAIR.mkdir(mode=0o700)
initial=dict(p)
for block,backend in enumerate(['native','reference','reference','native','native','reference']):
 OUT=PAIR/f'block-{block}-{backend}';OUT.mkdir(mode=0o700)
 result={'scope':'Same physical iPhone; model-free functional operations. No model/task/speed/release superiority claim','backend':backend,'block':block,'reference_sha':'3ce9c080534e89fab91a237bf1c53a4a7e9d80a7','wda_sha':'d17782422d55ff1e5e0ceb74eb1fd509cc0c35b6','native_revision':'e73f777c73b0bd40c9ba841c830a530d99a87039','frequency':60,'reference_verify':False,'reference_settle_seconds':0,'cases':[],'cleanup_errors':[]}
 p=dict(initial);processes=[];peer=None
 def api(path,body=None,runner=False):
  data=json.dumps(body).encode() if body is not None else None;method='POST' if data else 'GET';port=p['relay_port'] if runner else p['daemon_port']
  headers={'Content-Type':'application/json'}
  if runner:
   if backend=='native':headers['Authorization']=authorization(token,method,path,data or b'')
  else:headers.update(Authorization='Bearer '+token,**{'X-Phone-Control':'1','X-Phone-Owner':'physical-e73-paired'})
  req=urllib.request.Request(f'http://127.0.0.1:{port}'+path,data=data,headers=headers)
  with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req,timeout=5) as r:return json.load(r)
 try:
  old=plistlib.loads((Path.home()/'Library/LaunchAgents/com.leeguoo.iphone-use.plist').read_bytes()).get('EnvironmentVariables',{})
  q=urllib.request.Request('http://127.0.0.1:44321/agent/status',headers={'Authorization':'Bearer '+(old.get('IPHONE_USE_AGENT_TOKEN') or old['IPHONE_USE_PASSWORD'])})
  with urllib.request.urlopen(q,timeout=5) as r:status=json.load(r)
  assert not status.get('drivable') and status.get('owner') is None,'another phone session is active'
  relay=start('relay',[str(ROOT/'target/debug/iphone-use'),'relay','--udid',udid,'--listen','127.0.0.1:'+str(p['relay_port']),'--device-port',str(p['runner_port'])],env)
  re=dict(env);re.update(TEST_RUNNER_IPU_RUNNER_PORT=str(p['runner_port']),TEST_RUNNER_IPU_RUNNER_TOKEN=token,TEST_RUNNER_IPU_RUNNER_MJPEG_PORT='0',TEST_RUNNER_IPU_DAEMON_PORT='0',TEST_RUNNER_USE_PORT=str(p['runner_port']),TEST_RUNNER_MJPEG_SERVER_PORT='0')
  config=BASE/('physical-private.xctestrun' if backend=='native' else 'wda-physical-private.xctestrun')
  only='IPhoneUseRunnerUITests/RunnerTests/testServe' if backend=='native' else 'WebDriverAgentRunner/UITestingUITests/testRunner'
  runner=start('runner',['xcodebuild','test-without-building','-xctestrun',str(config),'-destination','id='+udid,'-only-testing:'+only,'-parallel-testing-enabled','NO'],re)
  deadline=time.monotonic()+160
  while True:
   try:
    if api('/status',runner=True).get('value',{}).get('ready'):break
   except Exception:pass
   assert runner.poll() is None and time.monotonic()<deadline,'backend not ready'
   time.sleep(.5)
  private=OUT/'state';runtime=OUT/'runtime';private.mkdir(mode=0o700);runtime.mkdir(mode=0o700)
  pe=dict(env);pe.update(IPHONE_USE_STATE_DIR=str(private),WDA_TYPING_FREQUENCY='60',WDA_SETTLE_SECONDS='0')
  if backend=='native':
   (private/'runner-token').write_text(token);(private/'runner-token').chmod(0o600)
   de=dict(env);de.update(IPHONE_USE_HOST='127.0.0.1',IPHONE_USE_PORT=str(p['daemon_port']),IPHONE_USE_UDID=udid,IPHONE_USE_INSTANCE='physical-e73-paired',TMPDIR=str(runtime),IPHONE_USE_STATE_DIR=str(private),IPHONE_USE_RUNNER_URL=f'http://127.0.0.1:{p["relay_port"]}',IPHONE_USE_RUNNER_MJPEG_URL=f'http://127.0.0.1:{p["relay_port"]}',IPHONE_USE_RUNNER_MANAGED='0',IPHONE_USE_AGENT_TOKEN=token,IPHONE_USE_PASSWORD='fixture-'+token,IPHONE_USE_AUTO_FOCUS='0',IPHONE_USE_IDLE_RELEASE_SECS='0',IPHONE_USE_FLOWS_NO_AUTO_UPDATE='1')
   daemon=start('daemon',[str(ROOT/'target/debug/iphone-use'),'serve'],de)
   deadline=time.monotonic()+35
   while True:
    try:
     if api('/agent/status').get('drivable'):break
    except Exception:pass
    assert daemon.poll() is None and time.monotonic()<deadline,'daemon not drivable'
    time.sleep(.3)
   pe.update(IPHONE_USE_URL=f'http://127.0.0.1:{p["daemon_port"]}',IPHONE_USE_TOKEN=token,IPHONE_USE_OWNER='physical-e73-paired',IPHONE_USE_MCP_PREWARM='0',IPHONE_USE_MCP_STRUCTURED='full')
   argv=[str(ROOT/'target/debug/iphone-use-mcp')]
  else:argv=['python3',str(REFERENCE/'server/iphone_use.py'),'--state-dir',str(private),'--url',f'http://127.0.0.1:{p["relay_port"]}']
  peer=paired.Peer(argv,pe,OUT/'mcp.log')
  command('xcrun','devicectl','device','process','launch','--device',udid,bundle,'--','--trial',f'pair-{block}-initial','--seed','short')
  boot,body=call('phone_status' if backend=='native' else 'pua_ready',{} if backend=='native' else {'screenshot':False,'recover':False})
  assert not boot.get('result',{}).get('isError'),'public readiness refused'
  tasks=['screen','long-read','ordinary','advance'] if block<4 else ['shift']
  for task in tasks:
   trial=f'physical-pair-{block}-{task}'
   before=reset(trial,'long' if task=='long-read' else 'short',shift=task=='shift',advance=task=='advance')
   active=api('/wda/activeAppInfo',runner=True).get('value',{})
   assert active.get('bundleId')==bundle and active.get('pid')==before['pid'],'foreground process mismatch'
   if task=='screen':name,args=('phone_elements',{'ocr':'off','limit':200}) if backend=='native' else ('pua_observe',{'mode':'tree','max_nodes':200})
   elif task=='long-read':name,args=('phone_read_value',{'identifier':'field-a'}) if backend=='native' else ('pua_find',{'selector':{'name':'field-a','type':'TextField'},'limit':1})
   else:
    text=('shift-focus-test-'+'字'*483) if task=='shift' else '字'*500
    name,args=('phone_type',{'text':text,'clear':True,'observe':False}) if backend=='native' else ('pua_type_text',{'text':text,'replace':True,'observe':'none','verify':False})
   started=time.monotonic();reply,body=call(name,args)
   rec={'task':task,'trial':trial,'before':before,'reply':reply,'response_ms_diagnostic':round((time.monotonic()-started)*1000,3)}
   if task=='screen':rec['postcondition_match']=all(x in json.dumps(reply,ensure_ascii=False) for x in ['field-a','field-b','field-multiline','field-secure','Paired fixture '+trial])
   elif task=='long-read':
    value=body.get('value') if backend=='native' else next((x.get('value') for x in body.get('elements',[]) if x.get('name')=='field-a'),None)
    rec.update(returned_characters=len(value) if isinstance(value,str) else None,postcondition_match=value=='queue-deadline-'+'字'*6000)
   else:
    time.sleep(.6);after=receipt(trial);rec['after']=after
    rec['requested_text_match']=after['fields']['a']['sha256']==hashlib.sha256(text.encode()).hexdigest()
    rec['next_field_unchanged']=after['fields']['b']==before['fields']['b']
   result['cases'].append(rec);save();print('block',block,backend,task,flush=True)
   if peer.pending is not None:raise RuntimeError('pending call; abort cohort')
   if body.get('outcome')=='unknown' or body.get('retry_safe') is False:
    result['stopped_after_unknown']=task;save();break
  result['experiment_finished']=True
 except BaseException as e:
  result['error']=str(e);result['traceback']=traceback.format_exc();print('ERROR',str(e),flush=True)
 finally:
  if peer:
   try:
    if backend=='native' and peer.pending is None:call('phone_release_owner',{})
    peer.close()
   except Exception as e:result['cleanup_errors'].append('peer: '+str(e))
  for name,proc in reversed(processes):
   try:paired.stop(proc)
   except Exception as e:result['cleanup_errors'].append(name+': '+str(e))
  save()
 if result.get('error') or result['cleanup_errors']:raise SystemExit(1)
