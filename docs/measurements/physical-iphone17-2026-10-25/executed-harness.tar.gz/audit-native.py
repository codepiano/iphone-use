from pathlib import Path
import json,hashlib,gzip,shutil
p=Path(__file__).resolve().parent;root=Path('/tmp/iphone-use-runner-input-target-guard');out=root/'docs/measurements/physical-iphone17-2026-10-25';out.mkdir(parents=True,exist_ok=True)
records=[]
for n in range(3,8):
 v=json.loads((p/f'attempt-{n}/results.json').read_text());assert v.get('experiment_finished') and not v.get('error') and not v['cleanup_errors'];records.extend(v['cases'])
assert len(records)==12 and len({r['trial'] for r in records})==12
h=lambda s:hashlib.sha256(s.encode()).hexdigest()
results=[]
for r in records:
 trial=r['trial'];before=r['before'];after=r.get('after',{});fields=after.get('fields',{});body=r['reply'].get('result',{}).get('structuredContent',{})
 if trial in ['selected-b','middle','unicode','ignore-once']:
  key='b' if trial=='selected-b' else 'a';text='MCP-selected-'+'字'*488 if trial=='selected-b' else '字'*64
  ok=r['requested_text_match'] and r['unselected_fields_unchanged'] and fields[key]['sha256']==h(text)
  if trial=='ignore-once':ok=ok and after['selection_commands']==2
  verdict='exact replacement, other field hashes unchanged'
 elif trial=='long-read':
  content='\n'.join(x.get('text','') for x in r['reply']['result'].get('content',[]) if x.get('type')=='text')
  value=json.loads(content).get('value');ok=value=='queue-deadline-'+'字'*6000 and before['fields']['a']['sha256']==h(value);verdict='6015 characters returned exactly'
 elif trial=='clear':ok=fields['a']['sha256']==h('') and r['unselected_fields_unchanged'];verdict='long field empty, other fields unchanged'
 elif trial in ['ignore-all','partial','secure']:
  ok=fields==before['fields'] and all(n==0 for n in after['events'].values()) and r['reply']['result'].get('isError') is True
  if trial=='ignore-all':ok=ok and after['selection_commands']==2
  if trial=='partial':ok=ok and after['selection_commands']==1
  verdict='refused, unchanged field hashes and zero edit events'
 elif trial=='value-change':
  ok=fields['a']['sha256']==h('new-draft-middle') and after['events']['a']==1 and after['selection_commands']==1 and r['unselected_fields_unchanged'];verdict='App changed value preserved, no replacement replay'
 elif trial=='advance':
  ok=after['advance_triggered'] and fields['a']['sha256']==h('') and fields['b']==before['fields']['b'] and body.get('outcome')=='unknown' and body.get('retry_safe') is False
  verdict='guarded stop; requested replacement failed, next field preserved'
 elif trial=='shift':
  ok=after['shift_trigger_length']==20 and fields['a']['characters']==20 and fields['b']['characters']==180 and body.get('outcome')=='unknown' and body.get('retry_safe') is False
  verdict='requested replacement failed; 180 characters reached B, remaining 300 not dispatched'
 assert ok,trial
 results.append({'trial':trial,'evidence_matches_expected_observation':True,'observation':verdict,'requested_text_match':r.get('requested_text_match'),'returned_error':r['reply'].get('result',{}).get('isError',False)})
summary={'scope':'Single physical iPhone 17 Pro Max, iOS27.2; model-free functional acceptance. No reference comparison or overall completion/safety/speed win implied by this lane.','source_revision':'e73f777c73b0bd40c9ba841c830a530d99a87039','cases':results,'ordinary_replacements_exact':'4/4 (501 chars once, 64 chars three times)','safety_limit':'At an App-driven focus shift after character 20, A received20/B180; no per-character isolation','cleanup_errors':[]}
(out/'native-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
raw=json.dumps({'attempts':{str(n):json.loads((p/f'attempt-{n}/results.json').read_text()) for n in range(3,8)}},ensure_ascii=False,indent=2).encode()
(out/'native-results.json.gz').write_bytes(gzip.compress(raw,mtime=0))
for name in ['build-receipt.json','wda-build-receipt.json','runner-source-hashes.json','startup-diagnostic.json']:
 if (p/name).exists():shutil.copyfile(p/name,out/name)
failures={'startup':json.loads((p/'attempt-1/results.json').read_text()),'controller_path_precondition':json.loads((p/'attempt-2/results.json').read_text())}
(out/'retained-startup-failures.json').write_text(json.dumps(failures,indent=2)+'\n')
print(json.dumps({'checked_cases':len(results),'ordinary_replacements':'4/4','scope':summary['scope']},ensure_ascii=False))
