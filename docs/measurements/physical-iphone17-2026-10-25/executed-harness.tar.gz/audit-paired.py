from pathlib import Path
import json,gzip,hashlib,tarfile,io,shutil
p=Path(__file__).resolve().parent;root=Path('/tmp/iphone-use-runner-input-target-guard');out=root/'docs/measurements/physical-iphone17-2026-10-25'
h=lambda s:hashlib.sha256(s.encode()).hexdigest();blocks=[]
for i,backend in enumerate(['native','reference','reference','native','native','reference']):
 v=json.loads((p/f'paired/block-{i}-{backend}/results.json').read_text());assert v.get('experiment_finished') and not v.get('error') and not v['cleanup_errors'];blocks.append(v)
 assert [x['task'] for x in v['cases']]==(['screen','long-read','ordinary','advance'] if i<4 else ['shift'])
 for r in v['cases']:
  before=r['before'];assert before['foreground_active'] and before['keyboard_did_show'] and before['focus']=='a'
  task=r['task'];after=r.get('after',{});fields=after.get('fields',{})
  if task=='screen':assert r['postcondition_match']
  if task=='long-read':assert r['returned_characters']==(6015 if backend=='native' else 512) and r['postcondition_match']==(backend=='native')
  if task=='ordinary':assert r['requested_text_match'] and fields['a']['sha256']==h('字'*500) and fields['b']['sha256']==h('')
  if task=='advance':
   assert after['advance_triggered'] and fields['b']['sha256']==h('keep-b')
   assert fields['a']['sha256']==h('' if backend=='native' else '字'*500)
   assert r['requested_text_match']==(backend=='reference')
  if task=='shift':
   assert after['shift_trigger_length']==20 and fields['a']['characters']==20 and fields['b']['characters']==(180 if backend=='native' else 480)
   assert r['requested_text_match'] is False
  if after:
   assert all(fields[k]==before['fields'][k] for k in ['multi','secure'])
   if task!='shift':assert r['next_field_unchanged']
summary={'scope':'One physical iPhone 17 Pro Max/iOS27.2 over localNetwork; model-free public stdio MCP operations, independent App-owned hashes. Small functional cohort; no speed/model/release/overall superiority conclusion.','abba_order':['native','reference','reference','native'],'abba_records':16,'separate_focus_shift_order':['native','reference'],'separate_focus_shift_records':2,'matched_typing_frequency':60,'reference_settle_seconds':0,'reference_verify':False,'fresh_required_field_inventory':{'native':'2/2','reference':'2/2'},'ordinary_500_character_replacement':{'native':'2/2 exact','reference':'2/2 exact'},'long_value_read':{'native':'2/2 exact, 6015 characters','reference':'tested pua_find: 512 characters in both runs'},'app_changes_focus_after_clear':{'native':'0/2 requested replacements; both guarded stops, A empty/B unchanged','reference':'2/2 requested replacements; refocuses A, B unchanged'},'app_changes_focus_at_character_20':{'native':'A20/B180; stops remaining300; full requested input fails','reference':'A20/B480; full requested input fails'},'cleanup_errors':[]}
(out/'paired-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'paired-results.json.gz').write_bytes(gzip.compress(json.dumps({'blocks':blocks},ensure_ascii=False,indent=2).encode(),mtime=0))
files={}
for n in range(3,8):files[f'native-attempt-{n}.py']=p/f'attempt-{n}/run-physical.py'
files.update({'run-paired.py':p/'run-paired.py','run-physical-helpers.py':p/'run-physical.py','audit-native.py':p/'audit-native.py','audit-paired.py':p/'audit-paired.py','paired-bench-fixture.swift':root/'scripts/paired-bench-fixture.swift','compare-native-wda-simulator.py':root/'scripts/compare-native-wda-simulator.py','runner_auth.py':root/'scripts/runner_auth.py'})
raw=io.BytesIO()
with tarfile.open(fileobj=raw,mode='w') as tar:
 for name,path in files.items():
  data=path.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
(out/'executed-harness.tar.gz').write_bytes(gzip.compress(raw.getvalue(),mtime=0))
manifest={'source_revision':'e73f777c73b0bd40c9ba841c830a530d99a87039','fixture_source_sha256':h((root/'scripts/paired-bench-fixture.swift').read_text()),'daemon_binary_sha256':hashlib.sha256((root/'target/debug/iphone-use').read_bytes()).hexdigest(),'mcp_binary_sha256':hashlib.sha256((root/'target/debug/iphone-use-mcp').read_bytes()).hexdigest(),'files':{x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in out.iterdir() if x.is_file() and x.name!='manifest.json'}}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('audited 16 ABBA records and 2 separate focus-shift records')
