from pathlib import Path
import argparse,importlib.util,json,sys,time,uuid,urllib.error,hashlib,traceback
p=argparse.ArgumentParser();p.add_argument('--runner-record',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'scripts'))
spec=importlib.util.spec_from_file_location('recovery',root/'scripts/test-replacement-recovery-simulator.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
record=json.loads(a.runner_record.read_text());a.udid=record['udid'];a.base='http://127.0.0.1:'+str(record['daemon_port']);a.owner='ax-bound-insert-probe'
d=r.drag.Daemon(a.base,a.owner);until=time.monotonic()+60
while True:
 status=d.call('/agent/status');assert status.get('owner') in (None,a.owner) and status.get('screen_private_secs',0)==0
 if status.get('drivable') is True:break
 if time.monotonic()>until:raise RuntimeError('owned Simulator readiness deadline')
 time.sleep(.2)
d.require_simulator(a.udid);d.call('/agent/hold',{'secs':300});r.require_target(d,a)
a.out.mkdir(mode=0o700,exist_ok=False);r.pair.fixture.FIXTURE=(root/'ax-insert-fixture.swift').read_text();r.pair.fixture.BUNDLE='com.leeguoo.iphone-use.ax-insert-probe';bundle=r.pair.fixture.BUNDLE
existing=r.subprocess.run(['xcrun','simctl','get_app_container',a.udid,bundle,'data'],capture_output=True,timeout=30);assert existing.returncode!=0,'refuse replacing existing fixture'
reports=[];errors=[];cleanup=[];pending=False;installed=False
cases=[
 ('unicode-append','short','field-a','中文🙂e\u0301👩\u200d💻'),
 ('long-append-a','short','field-a','字'*501),
 ('unfocused-b','short','field-b','字'*501),
 ('empty-a','empty','field-a','字'*501),
 ('caret-insert','middle','field-a','中文🙂e\u0301👩\u200d💻'),
 ('multiline','short','field-multiline','第一行\n第二行🙂'),
 ('focused-b','short','field-b','字'*501),
 ('focused-multiline','short','field-multiline','第一行\n第二行🙂'),
 ('focused-veto-multi','delegate-reject','field-multiline','字'*501),
 ('delegate-veto-a','delegate-reject','field-a','字'*501),
 ('delegate-veto-multi','delegate-reject','field-multiline','字'*501),
 ('delegate-handoff','delegate-handoff','field-a','字'*501),
 ('typing-control-veto-a','delegate-reject','field-a','check'),
 ('typing-control-veto-multi','delegate-reject','field-multiline','check'),
 ('typing-control-handoff','delegate-handoff','field-a','check'),
 ('secure-refusal','short','field-secure','dummy-only'),
]
try:
 r.wait_for_native_idle(d,a,phase='before_install')
 app=r.pair.fixture.build_fixture(a.out);r.pair.fixture.command('xcrun','simctl','install',a.udid,app);installed=True
 documents=Path(r.pair.fixture.command('xcrun','simctl','get_app_container',a.udid,bundle,'data',timeout=30))/'Documents';receipt=documents/'paired-state.json'
 r.pair.fixture.command('xcrun','simctl','launch',a.udid,bundle,'--trial','insert-warmup','--seed','short')
 for name,seed,target,text in cases:
  r.wait_for_native_idle(d,a,phase='before_'+name)
  trial='insert-'+uuid.uuid4().hex
  f=documents/'paired-reset.json.tmp';f.write_text(json.dumps({'trial':trial,'seed':seed,'advance':target=='field-b'}));f.replace(documents/'paired-reset.json')
  until=time.monotonic()+20
  while True:
   before=json.loads(receipt.read_text()) if receipt.exists() else {}
   if before.get('trial')==trial and before.get('foreground_active') and before.get('keyboard_did_show') and before.get('focus')=='a':break
   if time.monotonic()>until:raise RuntimeError('fixture setup deadline')
   time.sleep(.1)
  active,_=r.drag.runner_call(a,'/wda/activeAppInfo');assert active['value']['bundleId']==bundle and active['value']['pid']==before['pid']
  found,_=r.drag.runner_call(a,'/element',{'using':'accessibility id','value':target});item=found['value'];fid=item.get('ELEMENT') or item.get('element-6066-11e4-a52e-4f735466cecf');assert fid,item
  if name.startswith('focused-'):
   pending=True
   focused_reply,_=r.drag.runner_call(a,'/element/'+fid+'/click',{})
   pending=False
   r.wait_for_native_idle(d,a,phase='after_focus_'+name)
   wanted='b' if target=='field-b' else 'multi'
   until=time.monotonic()+10
   while True:
    before=json.loads(receipt.read_text())
    if before.get('focus')==wanted:break
    if time.monotonic()>until:raise RuntimeError('explicit focus did not settle')
    time.sleep(.1)
  path='/element/'+fid+'/value' if name.startswith('typing-control') else '/ipu/element/'+fid+'/ax-insert-probe'
  started=time.monotonic();pending=True
  try:reply,headers=r.drag.runner_call(a,path,{'text':text});http_status=200
  except urllib.error.HTTPError as error:reply=json.load(error);http_status=error.code
  pending=False;elapsed=time.monotonic()-started
  r.wait_for_native_idle(d,a,phase='after_'+name)
  until=time.monotonic()+2;after=json.loads(receipt.read_text())
  while True:
   time.sleep(.25);fresh=json.loads(receipt.read_text())
   if fresh==after:break
   after=fresh
   if time.monotonic()>until:raise RuntimeError('fixture receipts did not settle')
  reports.append({'case':name,'seed':seed,'target':target,'text_scalars':len(text),'text_sha256':hashlib.sha256(text.encode()).hexdigest(),'before':before,'after':after,'reply':reply,'http_status':http_status,'native_route_seconds':elapsed})
  (a.out/'result.json').write_text(json.dumps({'cases':reports,'errors':errors},ensure_ascii=False,indent=2)+'\n')
  print(json.dumps({'case':name,'reply':reply,'fields':after['fields'],'focus':after.get('focus'),'events':after.get('events'),'delegate_calls':after.get('delegate_calls'),'notifications':after.get('text_notifications'),'vetoes':after.get('delegate_denied'),'delegate_focus_shift':after.get('delegate_focus_shift'),'delegate_shift_scalars':after.get('delegate_shift_scalars'),'elapsed_seconds':elapsed}),flush=True)
except BaseException as error:
 errors.append(repr(error));(a.out/'traceback.txt').write_text(traceback.format_exc())
finally:
 try:
  if pending:raise RuntimeError('native delivery remains uncertain; fixture uninstall deferred')
  r.wait_for_native_idle(d,a,phase='before_cleanup')
  if installed:r.pair.fixture.command('xcrun','simctl','uninstall',a.udid,bundle,timeout=30)
 except Exception as error:cleanup.append(repr(error))
 (a.out/'result.json').write_text(json.dumps({'scope':'Isolated native AXElement insertText probe; independent App receipts, not product/API completion','cases':reports,'errors':errors,'cleanup_errors':cleanup,'pending':pending,'source_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ['ax-insert-probe.py','ax-insert-fixture.swift','runner/IPhoneUseRunner/IPhoneUseRunnerUITests/IPURBridge.m','runner/IPhoneUseRunner/IPhoneUseRunnerUITests/RunnerRoutes.swift']}},ensure_ascii=False,indent=2)+'\n')
raise SystemExit(1 if errors or cleanup else 0)
