from pathlib import Path
import traceback
import os,sys,subprocess,json,time,signal,urllib.request,urllib.error,importlib.util,hashlib,traceback,plistlib
ROOT=Path('/tmp/iphone-use-runner-input-target-guard');OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from runner_auth import authorization
spec=importlib.util.spec_from_file_location('paired',ROOT/'scripts/compare-native-wda-simulator.py');paired=importlib.util.module_from_spec(spec);spec.loader.exec_module(paired)
p=json.loads((OUT/'private.json').read_text());udid=p['udid'];bundle=p['fixture_id'];token=p['token']
env={k:v for k,v in os.environ.items() if not k.startswith(('IPHONE_USE_','PHONE_REMOTE_','IPU_','TEST_RUNNER_','SIMCTL_CHILD_'))}
env.update(DEVELOPER_DIR='/Applications/Xcode-27.2-beta2.app/Contents/Developer',DO_NOT_TRACK='1',IPHONE_USE_ANALYTICS='0')
processes=[];peer=None;result={'scope':'Isolated per-grapheme AX prototype on one physical iPhone; independent fixture receipts, not product or overall acceptance','candidate':'d9c3e67 plus isolated per-grapheme AX prototype','cases':[],'cleanup_errors':[]}
def save(): (OUT/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
def command(*args,timeout=65):
 r=subprocess.run(args,env=env,capture_output=True,text=True,timeout=timeout)
 if r.returncode:raise RuntimeError('command failed: '+str(args[:5])+' '+r.stderr[-1500:]+' '+r.stdout[-1200:])
 return r.stdout
def start(name,args,e):
 with (OUT/(name+'.log')).open('w') as log: proc=subprocess.Popen(args,env=e,stdout=log,stderr=log,start_new_session=True)
 processes.append((name,proc));return proc
def api(path,body=None,runner=False):
 data=json.dumps(body).encode() if body is not None else None;method='POST' if data else 'GET'
 port=p['relay_port'] if runner else p['daemon_port']
 auth=authorization(token,method,path,data or b'') if runner else 'Bearer '+token
 req=urllib.request.Request(f'http://127.0.0.1:{port}'+path,data=data,headers={'Authorization':auth,'Content-Type':'application/json','X-Phone-Control':'1','X-Phone-Owner':'physical-ax-character'})
 with urllib.request.urlopen(req,timeout=35) as r:return json.load(r)
def receipt(trial):
 target=OUT/('receipt-'+trial+'.json');target.unlink(missing_ok=True)
 command('xcrun','devicectl','device','copy','from','--device',udid,'--domain-type','appDataContainer','--domain-identifier',bundle,'--source','Documents/paired-state.json','--destination',str(target),'--timeout','20')
 return json.loads(target.read_text())
def reset(trial,seed='short',shift=False,secure=False,advance=False,clear_fault=''):
 f=OUT/'paired-reset.json';f.write_text(json.dumps({'trial':trial,'seed':seed,'shift':shift,'secure':secure,'advance':advance,'clear_fault':clear_fault}))
 command('xcrun','devicectl','device','copy','to','--device',udid,'--domain-type','appDataContainer','--domain-identifier',bundle,'--source',str(f),'--destination','Documents/paired-reset.json','--timeout','20')
 deadline=time.monotonic()+25
 while True:
  s=receipt(trial)
  if s.get('trial')==trial and s.get('foreground_active') and s.get('initial_focus_established') and s.get('keyboard_did_show') and s.get('focus')==('secure' if secure else 'a'):return s
  if time.monotonic()>deadline:raise RuntimeError('fixture reset did not converge: '+str(s))
  time.sleep(.3)
def call(name,args):
 reply=peer.request('tools/call',{'name':name,'arguments':args},timeout=100)
 return reply,paired.payload(reply)[2]
def observation():
 reply,body=call('phone_elements',{})
 if reply.get('result',{}).get('isError'):raise RuntimeError('observation refused')
 rows=body.get('elements',[])
 indexes={x.get('identifier'):i for i,x in enumerate(rows)}
 assert all(k in indexes for k in ['field-a','field-b','field-multiline','field-secure']),str(body)[:1200]
 return body['snapshot'],indexes

cases=[
 ('unicode-append','short','field-a','中文🙂e\u0301👩\u200d💻'),
 ('long-append-a','short','field-a','字'*501),
 ('unfocused-b','short','field-b','字'*501),
 ('empty-a','empty','field-a','字'*501),
 ('character-20-shift','empty','field-a','shift-focus-test-'+'字'*483),
 ('caret-insert','middle','field-a','中文🙂e\u0301👩\u200d💻'),
 ('multiline','short','field-multiline','第一行\n第二行🙂'),
 ('focused-b','short','field-b','字'*501),
 ('focused-multiline','short','field-multiline','第一行\n第二行🙂'),
 ('focused-veto-multi','delegate-reject','field-multiline','字'*501),
 ('delegate-veto-a','delegate-reject','field-a','字'*501),
 ('delegate-veto-multi','delegate-reject','field-multiline','字'*501),
 ('delegate-handoff','delegate-handoff','field-a','字'*501),
 ('typing-control-veto-a','delegate-reject','field-a','check'),
 ('typing-control-veto-multi','delegate-reject','field-multiline','check'),
 ('typing-control-handoff','delegate-handoff','field-a','check'),
 ('secure-refusal','short','field-secure','dummy-only'),
]

def stop_owned_test(signum,frame):
 raise KeyboardInterrupt('owned test stopped')
signal.signal(signal.SIGTERM,stop_owned_test)
signal.signal(signal.SIGINT,stop_owned_test)
(OUT/'controller.pid').write_text(str(os.getpid()))
if '--run-owned-test' not in sys.argv:
 raise SystemExit('Prepared only. Explicit --run-owned-test is required for the authorized owned-device test.')
pending=False
owned_absence_verified=False
fixture_install_attempted=False
runner_start_attempted=False
try:
 old=plistlib.loads((Path.home()/'Library/LaunchAgents/com.leeguoo.iphone-use.plist').read_bytes()).get('EnvironmentVariables',{})
 auth=old.get('IPHONE_USE_AGENT_TOKEN') or old.get('IPHONE_USE_PASSWORD')
 req=urllib.request.Request('http://127.0.0.1:44321/agent/status',headers={'Authorization':'Bearer '+auth})
 with urllib.request.urlopen(req,timeout=5) as response:existing=json.load(response)
 assert existing.get('owner') is None and not existing.get('drivable') and existing.get('screen_private_secs',0)==0 and not existing.get('human_handoff'),'existing service active/private; do not take over'
 result['existing_default_preserved']={'mode':existing.get('mode'),'owner':existing.get('owner'),'drivable':existing.get('drivable')};save()
 check=OUT/'lock-before-private.json'
 command('xcrun','devicectl','device','info','lockState','--device',udid,'--json-output',str(check),'--timeout','15')
 check.chmod(0o600);locked=json.loads(check.read_text()).get('result',{})
 assert locked.get('passcodeRequired') is False and locked.get('unlockedSinceBoot') is True,'phone needs its holder to unlock it'
 apps=OUT/'apps-before-private.json'
 command('xcrun','devicectl','device','info','apps','--device',udid,'--json-output',str(apps),'--timeout','20')
 apps.chmod(0o600);inventory=apps.read_text()
 assert bundle not in inventory and p['runner_id'] not in inventory,'owned bundle already installed; no overwrite'
 owned_absence_verified=True
 fixture_install_attempted=True
 command('xcrun','devicectl','device','install','app','--device',udid,str(OUT/'PhysicalFixture.app'),'--timeout','60')
 result['fixture_installed']=True;save()
 relay=start('relay',[str(OUT/'bin/iphone-use'),'relay','--udid',udid,'--listen','127.0.0.1:'+str(p['relay_port']),'--device-port',str(p['runner_port'])],env)
 re=dict(env);re.update(TEST_RUNNER_IPU_RUNNER_PORT=str(p['runner_port']),TEST_RUNNER_IPU_RUNNER_TOKEN=token,TEST_RUNNER_IPU_RUNNER_MJPEG_PORT='0',TEST_RUNNER_IPU_DAEMON_PORT='0')
 runner_start_attempted=True
 runner=start('runner',['xcodebuild','test-without-building','-xctestrun',str(OUT/'physical-private.xctestrun'),'-destination','id='+udid,'-only-testing:IPhoneUseRunnerUITests/RunnerTests/testServe','-parallel-testing-enabled','NO'],re)
 until=time.monotonic()+180
 while True:
  try:
   if api('/status',runner=True).get('value',{}).get('ready'):break
  except Exception:pass
  assert runner.poll() is None and relay.poll() is None and time.monotonic()<until,'one controlled Runner start failed; do not reconnect automatically'
  time.sleep(.5)
 result['runner_ready']=True;save()
 state=OUT/'state';runtime=OUT/'runtime';state.mkdir(mode=0o700,exist_ok=True);runtime.mkdir(mode=0o700,exist_ok=True)
 (state/'runner-token').write_text(token);(state/'runner-token').chmod(0o600)
 de=dict(env);de.update(IPHONE_USE_HOST='127.0.0.1',IPHONE_USE_PORT=str(p['daemon_port']),IPHONE_USE_UDID=udid,IPHONE_USE_INSTANCE='physical-ax-character',TMPDIR=str(runtime),IPHONE_USE_STATE_DIR=str(state),IPHONE_USE_RUNNER_URL=f'http://127.0.0.1:{p["relay_port"]}',IPHONE_USE_RUNNER_MJPEG_URL=f'http://127.0.0.1:{p["relay_port"]}',IPHONE_USE_RUNNER_MANAGED='0',IPHONE_USE_AGENT_TOKEN=token,IPHONE_USE_PASSWORD='fixture-'+token,IPHONE_USE_AUTO_FOCUS='0',IPHONE_USE_IDLE_RELEASE_SECS='0',IPHONE_USE_FLOWS_NO_AUTO_UPDATE='1',IPHONE_USE_NO_UPDATE_CHECK='1')
 daemon=start('daemon',[str(OUT/'bin/iphone-use'),'serve'],de)
 until=time.monotonic()+40
 while True:
  try:
   status=api('/agent/status')
   if status.get('drivable'):break
  except Exception:pass
  assert daemon.poll() is None and time.monotonic()<until,'private daemon not drivable'
  time.sleep(.2)
 api('/agent/hold',{'secs':300})
 command('xcrun','devicectl','device','process','launch','--device',udid,bundle,'--','--trial','physical-initial','--seed','short')
 def idle():
  until=time.monotonic()+15
  while True:
   status=api('/agent/status')
   assert status.get('owner')=='physical-ax-character' and status.get('screen_private_secs',0)==0 and status.get('drivable'),'control/owner/privacy changed'
   if api('/status',runner=True).get('value',{}).get('busy') is False:return
   assert time.monotonic()<until,'native busy; no new trial'
   time.sleep(.2)
 for name,seed,target,text in cases:
  idle();api('/agent/hold',{'secs':300})
  active=api('/wda/activeAppInfo',runner=True).get('value',{})
  assert active.get('bundleId')==bundle,'fixture no longer foreground; stop'
  trial='physical-'+name+'-'+str(len(result['cases']))
  before=reset(trial,seed,advance=target=='field-b',shift=name=='character-20-shift')
  active=api('/wda/activeAppInfo',runner=True).get('value',{})
  assert active.get('bundleId')==bundle and active.get('pid')==before['pid'],'foreground/process changed'
  item=api('/element',{'using':'accessibility id','value':target},runner=True)['value']
  fid=item.get('ELEMENT') or item.get('element-6066-11e4-a52e-4f735466cecf');assert fid
  if name.startswith('focused-'):
   pending=True;api('/element/'+fid+'/click',{},runner=True);pending=False;idle()
   wanted='b' if target=='field-b' else 'multi';until=time.monotonic()+10
   while True:
    before=receipt(trial)
    if before.get('focus')==wanted:break
    assert time.monotonic()<until,'explicit fixture focus failed'
    time.sleep(.2)
  path='/element/'+fid+'/value' if name.startswith('typing-control') else '/ipu/element/'+fid+'/ax-insert-probe'
  started=time.monotonic();pending=True
  try:reply=api(path,{'text':text},runner=True);http_status=200
  except urllib.error.HTTPError as error:reply=json.load(error);http_status=error.code
  pending=False;seconds=time.monotonic()-started;idle()
  active=api('/wda/activeAppInfo',runner=True).get('value',{})
  assert active.get('bundleId')==bundle and active.get('pid')==before['pid'],'foreground changed; stop before readback'
  after=receipt(trial);time.sleep(.3);stable=receipt(trial)
  assert after==stable,'fixture edits still changing; no next trial'
  result['cases'].append({'case':name,'seed':seed,'target':target,'text_scalars':len(text),'text_sha256':hashlib.sha256(text.encode()).hexdigest(),'before':before,'after':after,'reply':reply,'http_status':http_status,'native_route_seconds':seconds})
  save();print(json.dumps({'case':name,'reply':reply,'field_lengths':{k:v['characters'] for k,v in after['fields'].items()},'shift_trigger_length':after.get('shift_trigger_length'),'seconds':seconds}),flush=True)
except BaseException as error:
 result['harness_error']=repr(error);(OUT/'traceback-private.txt').write_text(traceback.format_exc());save()
finally:
 if pending:result['cleanup_errors'].append('native response remains pending; no input replay')
 for name,process in reversed(processes):
  try:paired.stop(process)
  except Exception as error:result['cleanup_errors'].append(name+': '+str(error))
 if owned_absence_verified and (fixture_install_attempted or runner_start_attempted):
  try:
   current_apps=OUT/'apps-cleanup-private.json'
   command('xcrun','devicectl','device','info','apps','--device',udid,'--json-output',str(current_apps),'--timeout','20')
   current_apps.chmod(0o600);current=current_apps.read_text()
   for app_id,attempted in [(bundle,fixture_install_attempted),(p['runner_id'],runner_start_attempted)]:
    if attempted and app_id in current:command('xcrun','devicectl','device','uninstall','app','--device',udid,app_id,'--timeout','30')
  except Exception as error:result['cleanup_errors'].append('owned uninstall: '+str(error))
 result['pending']=pending;save()
 print(json.dumps({'completed_cases':len(result['cases']),'harness_error':result.get('harness_error'),'cleanup_errors':result['cleanup_errors']}),flush=True)
