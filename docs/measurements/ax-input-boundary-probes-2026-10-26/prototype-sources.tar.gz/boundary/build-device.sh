#!/bin/bash
set -euo pipefail
build_root=/private/tmp/iphone-use-paired-01a16e44-20261025/recovery-candidate-20261026
trap 'echo "$?" > "$build_root/ax-boundary-device-build-exit"' EXIT
export PATH=/Users/leo/.cargo/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export DEVELOPER_DIR=/Applications/Xcode-27.0.app/Contents/Developer
export SDKROOT="$(/usr/bin/xcrun --sdk macosx --show-sdk-path)"
export XCODEBUILD=/private/tmp/iphone-use-paired-01a16e44-20261025/xcodebuild-unsigned-limited
export IPU_RUNNER_DERIVED_DATA="$build_root/ax-character-device-derived"
cd "$build_root"
nice -n 15 taskpolicy -b bash runner/build.sh --unsigned
mkdir ax-boundary-device-products
/usr/bin/xcrun --sdk iphoneos swiftc -O -parse-as-library -sdk "$(/usr/bin/xcrun --sdk iphoneos --show-sdk-path)" -target arm64-apple-ios15.0 ax-insert-fixture.swift -o ax-boundary-device-products/InputGuard
cp -R ax-character-device-derived/Build/Products/Debug-iphoneos ax-boundary-device-products/
cp ax-character-device-derived/Build/Products/*.xctestrun ax-boundary-device-products/
tar -czf ax-boundary-device-unsigned.tar.gz -C ax-boundary-device-products .
