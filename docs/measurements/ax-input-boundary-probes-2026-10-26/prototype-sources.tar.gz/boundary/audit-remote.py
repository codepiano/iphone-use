from pathlib import Path
import json,subprocess,hashlib
r=Path('/private/tmp/iphone-use-paired-01a16e44-20261025/recovery-candidate-20261026')
expected={'IPURBridge.h':'5f1b000f3d9f561158f4393dfa374daef06638044d5f7ca312b465f73067444f','IPURBridge.m':'ed16957de351dc69acf8f9b57d37e89a291fcab8647c4a364f887e5e1209074a','RunnerRoutes.swift':'74f4e260f8cc62727702c32b38ecc692d9918a1b9c11f80daa65a81c57476c6c'}
hashes={n:hashlib.sha256((r/'runner/IPhoneUseRunner/IPhoneUseRunnerUITests'/n).read_bytes()).hexdigest() for n in expected}
owned=[]
for k in ['ax-attribute-schema','ax-boundary']:
 p=r/k;owned.append((p/'owned-simulator').read_text().strip());assert (p/'exit').read_text().strip()=='0'
assert (r/'ax-boundary/device-exit').read_text().strip()=='0'
d=json.loads(subprocess.check_output(['/Applications/Xcode-27.0.app/Contents/Developer/usr/bin/simctl','list','devices','--json']))
remaining=[x['udid'] for group in d['devices'].values() for x in group if x['udid'] in owned]
ps=subprocess.check_output(['ps','-axo','pid=,command='],text=True).splitlines()
services=[]
for line in ps:
 if any('--instance '+k+'-01a16e44' in line for k in ['ax-attribute-schema','ax-boundary']) or any('/instances/'+k+'-01a16e44/' in line for k in ['ax-attribute-schema','ax-boundary']):services.append(int(line.strip().split()[0]))
a={'restored_source_sha256':hashes,'remaining_owned_simulators':remaining,'live_owned_service_pids':services,'device_build_exit':0};print(json.dumps(a));assert hashes==expected and not remaining and not services
