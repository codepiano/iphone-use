from pathlib import Path
import os,json,subprocess,urllib.request,plistlib,socket,hashlib
p=Path(__file__).resolve().parent;c=json.loads((p/'private.json').read_text());env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode-27.2-beta2.app/Contents/Developer')
after=p/'apps-after-private.json';r=subprocess.run(['xcrun','devicectl','device','info','apps','--device',c['udid'],'--json-output',str(after),'--timeout','20'],env=env,capture_output=True);assert r.returncode==0;after.chmod(0o600)
def apps(path):return {a['bundleIdentifier'] for a in json.loads(path.read_text())['result']['apps']}
before=apps(p/'apps-before-private.json');now=apps(after)
ports={}
for k in ['relay_port','daemon_port']:
 s=socket.socket();s.settimeout(.5);ports[k]=s.connect_ex(('127.0.0.1',c[k]))==0;s.close()
old=plistlib.loads((Path.home()/'Library/LaunchAgents/com.leeguoo.iphone-use.plist').read_bytes()).get('EnvironmentVariables',{});auth=old.get('IPHONE_USE_AGENT_TOKEN') or old.get('IPHONE_USE_PASSWORD')
with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:44321/agent/status',headers={'Authorization':'Bearer '+auth}),timeout=5) as q:status=json.load(q)
a={'owned_apps_absent':not ({c['fixture_id'],c['runner_id']}&now),'all_preexisting_apps_preserved':before<=now,'preexisting_count':len(before),'ports_listening':ports,'default_service':{k:status.get(k) for k in ['mode','owner','drivable','screen_private_secs','human_handoff']}}
(p/'cleanup-audit.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps(a));assert a['owned_apps_absent'] and a['all_preexisting_apps_preserved'] and not any(ports.values()) and status.get('owner') is None
