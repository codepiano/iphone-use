#!/bin/bash
set -euo pipefail
probe_root=/private/tmp/iphone-use-paired-01a16e44-20261025/recovery-candidate-20261026
probe_work="$probe_root/ax-attribute-schema"
export PATH=/Users/leo/.cargo/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export DEVELOPER_DIR=/Applications/Xcode-27.0.app/Contents/Developer
export SDKROOT="$(/usr/bin/xcrun --sdk macosx --show-sdk-path)"
export XCODEBUILD=/private/tmp/iphone-use-paired-01a16e44-20261025/xcodebuild-limited
export IPU_RUNNER_SRC="$probe_root/runner"
cd "$probe_root"
python3 - <<'PY'
import hashlib
from pathlib import Path
p=Path('runner/IPhoneUseRunner/IPhoneUseRunnerUITests')
expected={'IPURBridge.h':'5f1b000f3d9f561158f4393dfa374daef06638044d5f7ca312b465f73067444f','IPURBridge.m':'ed16957de351dc69acf8f9b57d37e89a291fcab8647c4a364f887e5e1209074a','RunnerRoutes.swift':'74f4e260f8cc62727702c32b38ecc692d9918a1b9c11f80daa65a81c57476c6c'}
for n,v in expected.items():assert hashlib.sha256((p/n).read_bytes()).hexdigest()==v,n
PY
mkdir -p "$probe_work/stock"
for probe_name in IPURBridge.h IPURBridge.m RunnerRoutes.swift; do
 cp "runner/IPhoneUseRunner/IPhoneUseRunnerUITests/$probe_name" "$probe_work/stock/$probe_name"
 cp "$probe_work/$probe_name" "runner/IPhoneUseRunner/IPhoneUseRunnerUITests/$probe_name"
done
probe_sim=
cleanup() {
 probe_result=$?
 if [ -n "$probe_sim" ]; then
  "$probe_root/target/debug/iphone-use" simulator stop "$probe_sim" --instance ax-attribute-schema-01a16e44 --shutdown > "$probe_work/stop.log" 2>&1 || true
  xcrun simctl delete "$probe_sim" > "$probe_work/delete.log" 2>&1 || true
 fi
 for probe_name in IPURBridge.h IPURBridge.m RunnerRoutes.swift; do cp "$probe_work/stock/$probe_name" "runner/IPhoneUseRunner/IPhoneUseRunnerUITests/$probe_name"; done
 echo "$probe_result" > "$probe_work/exit"
}
trap cleanup EXIT
probe_sim=$(xcrun simctl create ax-attribute-schema-01a16e44 com.apple.CoreSimulator.SimDeviceType.iPhone-17 com.apple.CoreSimulator.SimRuntime.iOS-26-2)
printf '%s\n' "$probe_sim" > "$probe_work/owned-simulator"
nice -n 15 taskpolicy -b "$probe_root/target/debug/iphone-use" simulator start "$probe_sim" --instance ax-attribute-schema-01a16e44
python3 "$probe_work/probe.py" --runner-record "$HOME/.iphone-use/instances/ax-attribute-schema-01a16e44/simulator.json" --out "$probe_work/result"
