from pathlib import Path
import os,sys,subprocess,json,time,signal,urllib.request,urllib.error,importlib.util,hashlib,traceback,plistlib
ROOT=Path('/tmp/iphone-use-runner-input-target-guard');OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from runner_auth import authorization
spec=importlib.util.spec_from_file_location('paired',ROOT/'scripts/compare-native-wda-simulator.py');paired=importlib.util.module_from_spec(spec);spec.loader.exec_module(paired)
p=json.loads((OUT/'private.json').read_text());udid=p['udid'];bundle=p['fixture_id'];token=p['token']
env={k:v for k,v in os.environ.items() if not k.startswith(('IPHONE_USE_','PHONE_REMOTE_','IPU_','TEST_RUNNER_','SIMCTL_CHILD_'))}
env.update(DEVELOPER_DIR='/Applications/Xcode-27.2-beta2.app/Contents/Developer',DO_NOT_TRACK='1',IPHONE_USE_ANALYTICS='0')
processes=[];peer=None;result={'scope':'Isolated experimental character-event native probe; current default path unchanged; no superiority conclusion','candidate':'417aae4 plus uncommitted guard-probe-v2.patch','cases':[],'cleanup_errors':[]}
def save(): (OUT/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
def command(*args,timeout=65):
 r=subprocess.run(args,env=env,capture_output=True,text=True,timeout=timeout)
 if r.returncode:raise RuntimeError('command failed: '+str(args[:5])+' '+r.stderr[-1500:]+' '+r.stdout[-1200:])
 return r.stdout
def start(name,args,e):
 with (OUT/(name+'.log')).open('w') as log: proc=subprocess.Popen(args,env=e,stdout=log,stderr=log,start_new_session=True)
 processes.append((name,proc));return proc
def api(path,body=None,runner=False):
 data=json.dumps(body).encode() if body is not None else None;method='POST' if data else 'GET'
 port=p['relay_port'] if runner else p['daemon_port']
 auth=authorization(token,method,path,data or b'') if runner else 'Bearer '+token
 req=urllib.request.Request(f'http://127.0.0.1:{port}'+path,data=data,headers={'Authorization':auth,'Content-Type':'application/json','X-Phone-Control':'1','X-Phone-Owner':'physical-e73-acceptance'})
 with urllib.request.urlopen(req,timeout=5) as r:return json.load(r)
def receipt(trial):
 target=OUT/('receipt-'+trial+'.json');target.unlink(missing_ok=True)
 command('xcrun','devicectl','device','copy','from','--device',udid,'--domain-type','appDataContainer','--domain-identifier',bundle,'--source','Documents/paired-state.json','--destination',str(target),'--timeout','20')
 return json.loads(target.read_text())
def reset(trial,seed='short',shift=False,secure=False,advance=False):
 f=OUT/'paired-reset.json';f.write_text(json.dumps({'trial':trial,'seed':seed,'shift':shift,'secure':secure,'advance':advance}))
 command('xcrun','devicectl','device','copy','to','--device',udid,'--domain-type','appDataContainer','--domain-identifier',bundle,'--source',str(f),'--destination','Documents/paired-reset.json','--timeout','20')
 deadline=time.monotonic()+25
 while True:
  s=receipt(trial)
  if s.get('trial')==trial and s.get('foreground_active') and s.get('initial_focus_established') and s.get('keyboard_did_show') and s.get('focus')==('secure' if secure else 'a'):return s
  if time.monotonic()>deadline:raise RuntimeError('fixture reset did not converge: '+str(s))
  time.sleep(.3)
def call(name,args):
 reply=peer.request('tools/call',{'name':name,'arguments':args},timeout=100)
 return reply,paired.payload(reply)[2]
def observation():
 reply,body=call('phone_elements',{})
 if reply.get('result',{}).get('isError'):raise RuntimeError('observation refused')
 rows=body.get('elements',[])
 indexes={x.get('identifier'):i for i,x in enumerate(rows)}
 assert all(k in indexes for k in ['field-a','field-b','field-multiline','field-secure']),str(body)[:1200]
 return body['snapshot'],indexes
try:
 # Respect the existing daemon's current owner before starting any phone UI work.
 old=plistlib.loads((Path.home()/'Library/LaunchAgents/com.leeguoo.iphone-use.plist').read_bytes()).get('EnvironmentVariables',{})
 auth=old.get('IPHONE_USE_AGENT_TOKEN') or old.get('IPHONE_USE_PASSWORD')
 req=urllib.request.Request('http://127.0.0.1:44321/agent/status',headers={'Authorization':'Bearer '+auth})
 with urllib.request.urlopen(req,timeout=5) as r:status=json.load(r)
 assert status.get('owner') is None and not status.get('drivable'),'existing service active: do not take over'
 command('xcrun','devicectl','device','install','app','--device',udid,str(OUT/'PhysicalFixture.app'),'--timeout','60')
 result['fixture_installed']=True;save()
 p['profile_proxy_port']=paired.port()
 relay=start('relay',[str(ROOT/'target/debug/iphone-use'),'relay','--udid',udid,'--listen','127.0.0.1:'+str(p['relay_port']),'--device-port',str(p['runner_port'])],env)
 proxy=start('header-profile',['python3',str(OUT/'header-profile-proxy.py'),'--port',str(p['profile_proxy_port']),'--upstream','http://127.0.0.1:'+str(p['relay_port']),'--out',str(OUT/'header-profile.jsonl')],env)
 re=dict(env);re.update(TEST_RUNNER_IPU_RUNNER_PORT=str(p['runner_port']),TEST_RUNNER_IPU_RUNNER_TOKEN=token,TEST_RUNNER_IPU_RUNNER_MJPEG_PORT='0',TEST_RUNNER_IPU_DAEMON_PORT='0')
 runner=start('runner',['xcodebuild','test-without-building','-xctestrun',str(OUT/'physical-private.xctestrun'),'-destination','id='+udid,'-only-testing:IPhoneUseRunnerUITests/RunnerTests/testServe','-parallel-testing-enabled','NO'],re)
 deadline=time.monotonic()+200
 while True:
  try:
   if api('/status',runner=True).get('value',{}).get('ready'):break
  except Exception:pass
  assert runner.poll() is None and relay.poll() is None and time.monotonic()<deadline,'isolated runner readiness failed; inspect private logs'
  time.sleep(1)
 result['runner_ready']=True;save()
 private=OUT/'state';runtime=OUT/'runtime';private.mkdir(mode=0o700,exist_ok=True);runtime.mkdir(mode=0o700,exist_ok=True)
 (private/'runner-token').write_text(token);(private/'runner-token').chmod(0o600)
 de=dict(env);de.update(IPHONE_USE_HOST='127.0.0.1',IPHONE_USE_PORT=str(p['daemon_port']),IPHONE_USE_UDID=udid,IPHONE_USE_INSTANCE='physical-e73',TMPDIR=str(runtime),IPHONE_USE_STATE_DIR=str(private),IPHONE_USE_RUNNER_URL=f'http://127.0.0.1:{p["profile_proxy_port"]}',IPHONE_USE_RUNNER_MJPEG_URL=f'http://127.0.0.1:{p["relay_port"]}',IPHONE_USE_RUNNER_MANAGED='0',IPHONE_USE_AGENT_TOKEN=token,IPHONE_USE_PASSWORD='fixture-'+token,IPHONE_USE_AUTO_FOCUS='0',IPHONE_USE_IDLE_RELEASE_SECS='0',IPHONE_USE_FLOWS_NO_AUTO_UPDATE='1')
 daemon=start('daemon',[str(ROOT/'target/debug/iphone-use'),'serve'],de)
 deadline=time.monotonic()+45
 while True:
  try:
   status=api('/agent/status')
   if status.get('drivable'):break
  except Exception:pass
  assert daemon.poll() is None and time.monotonic()<deadline,'candidate daemon not drivable'
  time.sleep(.5)
 result['daemon_drivable']=True;save()
 pe=dict(env);pe.update(IPHONE_USE_URL=f'http://127.0.0.1:{p["daemon_port"]}',IPHONE_USE_TOKEN=token,IPHONE_USE_OWNER='physical-e73-acceptance',IPHONE_USE_MCP_PREWARM='0',IPHONE_USE_MCP_STRUCTURED='full',IPHONE_USE_STATE_DIR=str(private))
 peer=paired.Peer([str(ROOT/'target/debug/iphone-use-mcp')],pe,OUT/'mcp.log')
 command('xcrun','devicectl','device','process','launch','--device',udid,bundle,'--','--trial','physical-initial','--seed','short')
 call('phone_status',{})
 cases=[('selected-b','short','field-b','probe123'),('middle','middle','field-a','字'*8),('unicode','unicode','field-a','字'*8),('ignore-once','ignore-once','field-a','字'*8),('ignore-all','ignore-all','field-a','字'*8),('partial','selection-partial','field-a','字'*8),('value-change','selection-mutates','field-a','字'*8),('long-read','long','field-a',None),('clear','long','field-a',''),('secure','short','field-secure','refused'),('advance','short','field-a','字'*500),('shift','short','field-a','shift-focus-test-'+'字'*483)]
 selected=os.environ.get("PHYSICAL_CASES","").split(",")
 if selected!=[""]:cases=sorted([c for c in cases if c[0] in selected],key=lambda c:selected.index(c[0]))
 for trial,seed,target,value in cases:
  before=reset(trial,seed,shift=trial=='shift',secure=trial=='secure',advance=trial=='advance')
  snap,indexes=observation()
  record={'trial':trial,'before':before}
  if value is None:
   reply,body=call('phone_read_value',{'identifier':target,'max_utf16':10000})
   record.update(reply=reply,postcondition_match=body.get('value')=='queue-deadline-'+'字'*6000)
  else:
   reply,body=call('phone_set_value',{'element':indexes[target],'snapshot':snap,'value':value,'observe':False})
   time.sleep(.5);after=receipt(trial);record.update(reply=reply,after=after)
   fields=after.get('fields',{});key='b' if target=='field-b' else 'secure' if target=='field-secure' else 'a'
   record['requested_text_match']=fields.get(key,{}).get('sha256')==hashlib.sha256(value.encode()).hexdigest()
   record['unselected_fields_unchanged']=all(fields.get(k)==before['fields'][k] for k in before['fields'] if k!=key)
  result['cases'].append(record);save();print('finished',trial,flush=True)
  if body.get('outcome')=='unknown' or body.get('retry_safe') is False:
   result['stopped_after_unknown_or_unsafe_retry']=trial;save();break
 result['experiment_finished']=True
except BaseException as e:
 result['error']=str(e);result['traceback']=traceback.format_exc();save();print(type(e).__name__,str(e),flush=True)
finally:
 if peer:
  try:
   if peer.pending is None:call('phone_release_owner',{})
   peer.close()
  except Exception as e:result['cleanup_errors'].append('peer: '+str(e))
 for name,process in reversed(processes):
  try:paired.stop(process)
  except Exception as e:result['cleanup_errors'].append(name+': '+str(e))
 save()
