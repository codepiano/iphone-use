from pathlib import Path
import json,sys,time,urllib.request
sys.path.insert(0,str(Path(__file__).resolve().parent/'scripts'))
from runner_auth import authorization
record=Path(sys.argv[1]);out=Path(sys.argv[2]);data=json.loads(record.read_text());token=(record.parent/'runner-token').read_text().strip()
until=time.monotonic()+60
while True:
 request=urllib.request.Request('http://127.0.0.1:'+str(data['daemon_port'])+'/agent/status',headers={'X-Phone-Owner':'ax-text-inventory'})
 with urllib.request.urlopen(request,timeout=5) as response:status=json.load(response)
 assert status.get('owner') in (None,'ax-text-inventory') and status.get('screen_private_secs',0)==0
 if status.get('drivable') is True:break
 if time.monotonic()>until:raise RuntimeError('owned Simulator not drivable')
 time.sleep(.2)
path='/ipu/ax-text-inventory'
request=urllib.request.Request('http://127.0.0.1:'+str(data['port'])+path,headers={'Authorization':authorization(token,'GET',path,b'')})
with urllib.request.urlopen(request,timeout=30) as response:body=json.load(response)
out.write_text(json.dumps(body,indent=2)+'\n')
print(json.dumps({'inventory_received':True,'scope':body.get('value',{}).get('scope')}))
