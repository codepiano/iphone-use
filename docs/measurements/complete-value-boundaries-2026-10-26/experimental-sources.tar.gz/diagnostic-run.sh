#!/bin/bash
set -euo pipefail
root=/private/tmp/iphone-use-paired-01a16e44-20261025/recovery-candidate-20261026
work="$root/long-value-20261026"
export PATH=/Users/leo/.cargo/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export DEVELOPER_DIR=/Applications/Xcode-27.0.app/Contents/Developer
export SDKROOT="$(xcrun --sdk macosx --show-sdk-path)"
export XCODEBUILD="$work/xcodebuild-compile-background"
export IPU_RUNNER_SRC="$work/runner-private"
export DO_NOT_TRACK=1 IPHONE_USE_ANALYTICS=0 IPHONE_USE_NO_UPDATE_CHECK=1 IPHONE_USE_FLOWS_NO_AUTO_UPDATE=1
cd "$root"
python3 - <<'PREP'
from pathlib import Path
import shutil
p=Path('long-value-20261026');shutil.copytree('runner',p/'runner-private',ignore=shutil.ignore_patterns('build','DerivedData*','xcuserdata'))
for n in ['IPURBridge.h','IPURBridge.m','RunnerRoutes.swift']:shutil.copy2(p/n,p/'runner-private/IPhoneUseRunner/IPhoneUseRunnerUITests'/n)
PREP
sim=
cleanup() {
 result=$?
 if [ -n "$sim" ]; then
  "$root/target/debug/iphone-use" simulator stop "$sim" --instance long-value-01a16e44 --shutdown > "$work/stop.log" 2>&1 || true
  xcrun simctl delete "$sim" > "$work/delete.log" 2>&1 || true
 fi
 echo "$result" > "$work/exit"
}
trap cleanup EXIT
sim=$(xcrun simctl create long-value-01a16e44 com.apple.CoreSimulator.SimDeviceType.iPhone-17 com.apple.CoreSimulator.SimRuntime.iOS-26-2)
printf '%s\n' "$sim" > "$work/owned-simulator"
"$root/target/debug/iphone-use" simulator start "$sim" --instance long-value-01a16e44
python3 "$work/probe.py" --runner-record "$HOME/.iphone-use/instances/long-value-01a16e44/simulator.json" --out "$work/result"
