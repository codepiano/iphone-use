#!/bin/bash
set -euo pipefail
root=/private/tmp/iphone-use-paired-01a16e44-20261025/recovery-candidate-20261026
work="$root/launch-followup-20261026"
export PATH=/Users/leo/.cargo/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export DEVELOPER_DIR=/Applications/Xcode-27.0.app/Contents/Developer
export SDKROOT="$(xcrun --sdk macosx --show-sdk-path)"
export XCODEBUILD="$work/xcodebuild-compile-background"
export IPU_RUNNER_SRC="$work/runner-private"
export DO_NOT_TRACK=1 IPHONE_USE_ANALYTICS=0 IPHONE_USE_NO_UPDATE_CHECK=1 IPHONE_USE_FLOWS_NO_AUTO_UPDATE=1
cd "$root"
cp "$work/RunnerRoutes.swift" "$work/RunnerRoutes-before-full.swift"
cp "$work/RunnerRoutes-full.swift" "$work/RunnerRoutes.swift"
cp "$work/RunnerRoutes.swift" "$work/runner-private/IPhoneUseRunner/IPhoneUseRunnerUITests/RunnerRoutes.swift"
sim=
cleanup() {
 result=$?
 if [ -n "$sim" ]; then
  "$root/target/debug/iphone-use" simulator stop "$sim" --instance launch-public5-01a16e44 --shutdown > "$work/public-stop5.log" 2>&1 || true
  xcrun simctl delete "$sim" > "$work/public-delete5.log" 2>&1 || true
 fi
 echo "$result" > "$work/public-exit5"
}
trap cleanup EXIT
sim=$(xcrun simctl create launch-public5-01a16e44 com.apple.CoreSimulator.SimDeviceType.iPhone-17 com.apple.CoreSimulator.SimRuntime.iOS-26-2)
printf '%s\n' "$sim" > "$work/public-owned-simulator5"
"$root/target/debug/iphone-use" simulator start "$sim" --instance launch-public5-01a16e44
python3 "$work/probe.py" --runner-record "$HOME/.iphone-use/instances/launch-public5-01a16e44/simulator.json" --out "$work/public-result5"
