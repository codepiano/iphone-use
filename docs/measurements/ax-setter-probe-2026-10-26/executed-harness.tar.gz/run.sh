#!/bin/bash
set -euo pipefail
probe_root=/private/tmp/iphone-use-paired-01a16e44-20261025/recovery-candidate-20261026
trap 'echo "$?" > "$probe_root/ax-setter-exit"' EXIT
export PATH=/Users/leo/.cargo/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export DEVELOPER_DIR=/Applications/Xcode-27.0.app/Contents/Developer
export SDKROOT="$(/usr/bin/xcrun --sdk macosx --show-sdk-path)"
export XCODEBUILD=/private/tmp/iphone-use-paired-01a16e44-20261025/xcodebuild-limited
export IPU_RUNNER_SRC="$probe_root/runner"
cd "$probe_root"
probe_sim=$(xcrun simctl create ax-setter-01a16e44 com.apple.CoreSimulator.SimDeviceType.iPhone-17 com.apple.CoreSimulator.SimRuntime.iOS-26-2)
printf '%s\n' "$probe_sim" > ax-setter-owned-simulator
cleanup() {
 "$probe_root/target/debug/iphone-use" simulator stop "$probe_sim" --instance ax-setter-01a16e44 --shutdown > ax-setter-stop.log 2>&1 || true
 xcrun simctl delete "$probe_sim" > ax-setter-delete.log 2>&1
}
trap 'probe_status=$?; cleanup; echo "$probe_status" > "$probe_root/ax-setter-exit"' EXIT
nice -n 15 taskpolicy -b "$probe_root/target/debug/iphone-use" simulator start "$probe_sim" --instance ax-setter-01a16e44
probe_record="$HOME/.iphone-use/instances/ax-setter-01a16e44/simulator.json"
probe_port=$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["daemon_port"])' "$probe_record")
python3 ax-setter-probe.py --base "http://127.0.0.1:$probe_port" --udid "$probe_sim" --runner-record "$probe_record" --out "$probe_root/ax-setter-result"
