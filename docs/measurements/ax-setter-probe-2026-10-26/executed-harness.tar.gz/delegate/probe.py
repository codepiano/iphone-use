import argparse, hashlib, importlib.util, json, sys, time, uuid
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--base');p.add_argument('--udid');p.add_argument('--runner-record',type=Path);p.add_argument('--out',type=Path);a=p.parse_args()
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'scripts'))
spec=importlib.util.spec_from_file_location('recovery',root/'scripts/test-replacement-recovery-simulator.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
a.owner='ax-setter-probe';d=r.drag.Daemon(a.base,a.owner)
until=time.monotonic()+60
while True:
 status=d.call('/agent/status')
 if status.get('owner') not in (None,a.owner) or status.get('screen_private_secs',0)!=0:raise RuntimeError('owner/privacy refuses probe')
 if status.get('drivable') is True:break
 if time.monotonic()>until:raise RuntimeError('daemon readiness timeout')
 time.sleep(.5)
d.require_simulator(a.udid)
d.call('/agent/hold',{'secs':300})
r.require_target(d,a)
a.out.mkdir(mode=0o700,exist_ok=False)
r.pair.fixture.FIXTURE=(root/'ax-setter-fixture.swift').read_text();r.pair.fixture.BUNDLE='com.leeguoo.iphone-use.ax-setter-probe'
bundle=r.pair.fixture.BUNDLE
existing=r.subprocess.run(['xcrun','simctl','get_app_container',a.udid,bundle,'data'],capture_output=True)
assert existing.returncode !=0,'existing probe app'
app=r.pair.fixture.build_fixture(a.out);r.pair.fixture.command('xcrun','simctl','install',a.udid,app)
reports=[];errors=[]
try:
 r.pair.fixture.command('xcrun','simctl','launch',a.udid,bundle,'--trial','ax-warmup','--seed','short')
 documents=Path(r.pair.fixture.command('xcrun','simctl','get_app_container',a.udid,bundle,'data'))/'Documents'
 receipt=documents/'paired-state.json'
 for name,target,text,shift in [('unicode','field-a','中文🙂e\u0301👩\u200d💻',False),('long-a','field-a','字'*501,False),('unfocused-b','field-b','字'*501,False),('shift-diagnostic','field-a','shift-focus-test-'+'字'*483,True),('multiline','field-multiline','第一行\n第二行🙂',False),('delegate-reject','field-a','字'*501,False),('delegate-reject-multi','field-multiline','字'*501,False),('typing-control-reject','field-a','check',False),('typing-control-reject-multi','field-multiline','check',False)]:
  r.require_target(d,a);status,_=r.drag.runner_call(a,'/status');assert status['value']['busy'] is False
  trial='ax-'+uuid.uuid4().hex
  temp=documents/'paired-reset.json.tmp';temp.write_text(json.dumps({'trial':trial,'seed':'delegate-reject' if 'reject' in name else 'short','shift':shift}));temp.replace(documents/'paired-reset.json')
  until=time.monotonic()+20
  while True:
   before=json.loads(receipt.read_text()) if receipt.exists() else {}
   if before.get('trial')==trial and before.get('focus')=='a' and before.get('keyboard_did_show') and before.get('foreground_active'):break
   if time.monotonic()>until:raise RuntimeError('fixture setup timeout')
   time.sleep(.1)
  active,_=r.drag.runner_call(a,'/wda/activeAppInfo');assert active['value']['bundleId']==bundle and active['value']['pid']==before['pid']
  found,_=r.drag.runner_call(a,'/element',{'using':'accessibility id','value':target})
  item=found['value'];fid=item.get('ELEMENT') or item.get('element-6066-11e4-a52e-4f735466cecf');assert fid,item
  started=time.monotonic();reply,_=r.drag.runner_call(a,('/element/'+fid+'/value') if name.startswith('typing-control') else ('/ipu/element/'+fid+'/ax-setter-probe'),{'text':text});elapsed=time.monotonic()-started
  idle,_=r.drag.runner_call(a,'/status');assert idle['value']['busy'] is False
  time.sleep(.25);after=json.loads(receipt.read_text());time.sleep(.25);stable=json.loads(receipt.read_text());assert stable==after
  reports.append({'case':name,'before':before,'after':after,'reply':reply,'elapsed_seconds':elapsed,'expected_sha256':hashlib.sha256(text.encode()).hexdigest()})
  (a.out/'result.json').write_text(json.dumps({'cases':reports,'errors':errors},ensure_ascii=False,indent=2))
  print(json.dumps({'case':name,'reply':reply,'fields':after['fields'],'events':after['events'],'shift':after.get('shift_trigger_length'),'delegate_calls':after.get('delegate_calls'),'notifications':after.get('text_notifications'),'denied':after.get('delegate_denied'),'elapsed':elapsed}),flush=True)
except Exception as e:
 errors.append(str(e));raise
finally:
 (a.out/'result.json').write_text(json.dumps({'cases':reports,'errors':errors},ensure_ascii=False,indent=2))
 status,_=r.drag.runner_call(a,'/status')
 if status['value']['busy'] is False:r.pair.fixture.command('xcrun','simctl','uninstall',a.udid,bundle)
