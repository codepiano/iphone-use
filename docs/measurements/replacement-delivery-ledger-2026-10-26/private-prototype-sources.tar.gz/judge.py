from pathlib import Path
import json,hashlib,sys
p=Path(sys.argv[1]);d=json.loads(p.read_text());h=lambda s:hashlib.sha256(s.encode()).hexdigest()
def payload(r):
 v=r['reply'].get('result',{});text='\n'.join(c.get('text','') for c in v.get('content',[]) if c.get('type')=='text')
 try:b=json.loads(text)
 except ValueError:b=v.get('structuredContent',{})
 return v,b
issues=[];checks=[]
for r in d['cases']:
 name=r['case'];before=r['before'];after=r['after'];result,b=payload(r);bad=[]
 def need(ok,msg):
  if not ok:bad.append(msg)
 key='multi' if name=='type-multiline' else 'a'
 for k in before['fields']:
  if k!=key:need(before['fields'][k]==after['fields'][k],'unrelated field changed: '+k)
 if 'focus-' in name:
  n=221 if '221' in name else 20;text='shift-focus-test-'+'字'*(501-len('shift-focus-test-'))
  need(after['shift_trigger_length']==n,'fault not reached')
  need(after['fields']['a']['sha256']==h(text[:n]),'wrong original prefix')
  need(after['fields']['b']==before['fields']['b'],'text spilled to B')
  need(after['a_touch_starts']==after['a_touches_at_shift'],'refocus after failure')
  need(result.get('isError') is True and b.get('retry_safe') is False,'failure/unsafe-replay verdict lost')
  need(b.get('characters_confirmed')==(200 if n==221 else 0),'confirmed prefix count wrong')
  need(b.get('characters_uncertain')==200,'uncertain chunk lost')
  if 'replace-' in name:
   need(b.get('characters_unsent')==(101 if n==221 else 301),'unsent suffix wrong')
   need(b.get('clear_outcome')==('confirmed' if n==221 else 'unknown'),'clear receipt wrong')
   need(b.get('outcome')=='unknown','unknown current segment promoted')
  if name.startswith('batch-'):
   need(b.get('failed_step')==1 and b.get('completed')==1 and b.get('applied_actions')==1,'completed batch prefix lost')
   need(b.get('batch_outcome')=='unknown','unknown batch promoted')
   need(len(b.get('steps',[]))==1,'later suffix ran or prefix omitted')
 elif 'veto' in name:
  need(after['fields']==before['fields'],'veto did not preserve fields')
  need(after['delegate_calls']['a']>=1 and after['delegate_denied']>=1,'requested delegate veto not reached')
  need(result.get('isError') is True and b.get('retry_safe') is False,'veto incorrectly completed')
 else:
  wanted={'type-501':'old'+'字'*501,'type-empty-501':'字'*501,
   'type-unicode':'old'+'中文🙂e\u0301👩\u200d💻','type-multiline':'第一行\n第二行🙂',
   'replace-501':'字'*501,'replace-clear-handoff':'字'*501,
   'type-after-long-seed':'queue-deadline-'+'字'*6501}[name]
  need(after['fields'][key]['sha256']==h(wanted),'requested App content not complete')
  need(b.get('ok') is True and not result.get('isError'),'task did not complete')
  if name=='replace-clear-handoff':
   need(after['advance_triggered'] is True,'clear handoff not exercised')
   need(after['a_touch_starts']-after['a_touches_at_clear']==1,'not exactly one clear-time restoration')
 checks.append({'case':name,'verified':not bad,'errors':bad,'seconds':r['seconds'],'mode':r.get('structured_mode')})
 if bad:issues.append({'case':name,'errors':bad})
out={'records':len(d['cases']),'expected_records':16,'harness_errors':d['errors'],'cleanup_errors':d['cleanup_errors'],'case_checks':checks,'issues':issues,'passed':len(d['cases'])==16 and not issues and not d['errors'] and not d['cleanup_errors'] and not d['pending']}
(p.parent/'independent-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False,indent=2))
raise SystemExit(0 if out['passed'] else 1)
