from pathlib import Path
import argparse,importlib.util,json,sys,time,uuid,urllib.error,hashlib,traceback,os
p=argparse.ArgumentParser();p.add_argument('--runner-record',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
P=Path(__file__).resolve().parent;ROOT=Path(os.environ.get('IPU_PUBLIC_PROBE_ROOT',str(P.parent)));sys.path.insert(0,str(ROOT/'scripts'))
spec=importlib.util.spec_from_file_location('recovery',ROOT/'scripts/test-replacement-recovery-simulator.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
record=json.loads(a.runner_record.read_text());a.udid=record['udid'];a.base='http://127.0.0.1:'+str(record['daemon_port']);a.owner='ax-public-pipeline'
d=r.drag.Daemon(a.base,a.owner);until=time.monotonic()+60
while True:
 status=d.call('/agent/status');assert status.get('target')=='simulator' and status.get('udid','').lower()==a.udid.lower() and status.get('owner') in (None,a.owner) and status.get('screen_private_secs',0)==0
 if status.get('drivable') is True:break
 if time.monotonic()>until:raise RuntimeError('owned daemon did not become drivable; no input sent')
 time.sleep(.2)
d.require_simulator(a.udid);d.call('/agent/hold',{'secs':600});r.require_target(d,a)
a.out.mkdir(mode=0o700,exist_ok=False)
r.pair.fixture.FIXTURE=(P/'fixture.swift').read_text();r.pair.fixture.BUNDLE='com.leeguoo.iphone-use.ax-public-pipeline';bundle=r.pair.fixture.BUNDLE
existing=r.subprocess.run(['xcrun','simctl','get_app_container',a.udid,bundle,'data'],capture_output=True,timeout=30);assert existing.returncode!=0,'existing fixture must not be overwritten'
environment={k:v for k,v in os.environ.items() if not k.startswith(('IPHONE_USE_','PHONE_REMOTE_','IPU_','TEST_RUNNER_'))}
environment.update(IPHONE_USE_URL=a.base,IPHONE_USE_OWNER=a.owner,IPHONE_USE_MCP_PREWARM='0',IPHONE_USE_MCP_STRUCTURED='full',IPHONE_USE_STATE_DIR=str(a.out/'mcp-state'),IPHONE_USE_FLOWS_NO_AUTO_UPDATE='1')
last_setup=None;setup_launch=None;mode='full';discovery=None;peer=None;installed=False;pending=False;rows=[];errors=[];cleanup=[];current=None
shift='shift-focus-test-'+'字'*(501-len('shift-focus-test-'))
cases=[
 ('type-501','type','short','field-a','字'*501,False,0,False),
 ('type-empty-501','type','empty','field-a','字'*501,False,0,False),
 ('type-unicode','type','short','field-a','中文🙂e\u0301👩\u200d💻',False,0,False),
 ('type-focus-20','type','empty','field-a',shift,False,20,False),
 ('type-focus-221','type','empty','field-a',shift,False,221,False),
 ('type-veto','type','delegate-reject','field-a','字'*501,False,0,False),
 ('type-multiline','type','short','field-multiline','第一行\n第二行🙂',False,0,False),
 ('replace-501','replace','short','field-a','字'*501,False,0,False),
 ('replace-focus-20','replace','empty','field-a',shift,False,20,False),
 ('replace-focus-221','replace','empty','field-a',shift,False,221,False),
 ('replace-veto','replace','delegate-reject','field-a','字'*501,False,0,False),
 ('replace-clear-handoff','replace','short','field-a','字'*501,True,0,True),
 ('batch-replace-focus-20','batch','empty','field-a',shift,False,20,False),
 ('batch-replace-focus-221','batch','empty','field-a',shift,False,221,False),
 ('batch-default-replace-focus-221','batch','empty','field-a',shift,False,221,False),
 ('type-after-long-seed','type','long','field-a','字'*501,False,0,False),
]
def save():
 (a.out/'result.json').write_text(json.dumps({'scope':'Owned Simulator; real stdio MCP and daemon, private target-bound character Runner; no product default change','setup_launch':setup_launch,'last_setup':last_setup,'mcp_discovery':discovery,'cases':rows,'errors':errors,'cleanup_errors':cleanup,'pending':pending,'in_flight':current,'harness_sha256':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['scripts/test-replacement-recovery-simulator.py','scripts/test-drag-simulator.py']},'source_sha256':{n:hashlib.sha256((P/n).read_bytes()).hexdigest() for n in ['probe.py','fixture.swift','IPURBridge.h','IPURBridge.m','RunnerRoutes.swift']},'binary_sha256':{n:hashlib.sha256((ROOT/'target/debug'/n).read_bytes()).hexdigest() for n in ['iphone-use','iphone-use-mcp']}},ensure_ascii=False,indent=2)+'\n')
def call(name,arguments):return peer.request('tools/call',{'name':name,'arguments':arguments},timeout=80)
try:
 r.wait_for_native_idle(d,a,phase='before_install')
 app=r.pair.fixture.build_fixture(a.out);r.pair.fixture.command('xcrun','simctl','install',a.udid,app);installed=True
 docs=Path(r.pair.fixture.command('xcrun','simctl','get_app_container',a.udid,bundle,'data',timeout=30))/'Documents';receipt=docs/'paired-state.json'
 peer=r.pair.Peer([str(ROOT/'target/debug/iphone-use-mcp')],environment,a.out/'mcp.log')
 listing=peer.request('tools/list',{});names=[x['name'] for x in listing['result']['tools']];assert {'phone_elements','phone_type','phone_set_value','phone_run_steps'}<=set(names)
 discovery={'count':len(names),'names':names,'tools_list_sha256':hashlib.sha256(json.dumps(listing,sort_keys=True).encode()).hexdigest()}
 setup_launch=call('phone_run_steps',{'steps':[{'kind':'launch_app','bundle':bundle}],'observe':False});save()
 launch_result,_,launch_body=r.pair.payload(setup_launch);assert not launch_result.get('isError') and launch_body.get('ok') is True,'owned fixture public launch failed'
 warmup_deadline=time.monotonic()+20
 while True:
  warm=json.loads(receipt.read_text()) if receipt.exists() else {}
  last_setup={'phase':'warmup','receipt':warm};save()
  if warm.get('foreground_active') and warm.get('initial_focus_established') and warm.get('keyboard_did_show') and warm.get('focus')=='a':break
  if time.monotonic()>warmup_deadline:raise RuntimeError('owned fixture warmup did not converge; setup receipt retained')
  time.sleep(.1)
 for name,kind,seed,target,text,advance,threshold,recover in cases:
  if name.startswith('batch-default-'):
   mode='default';peer.close();default_environment=dict(environment);default_environment.pop('IPHONE_USE_MCP_STRUCTURED',None);default_environment['IPHONE_USE_STATE_DIR']=str(a.out/'mcp-default-state')
   peer=r.pair.Peer([str(ROOT/'target/debug/iphone-use-mcp')],default_environment,a.out/'mcp-default.log')
  r.wait_for_native_idle(d,a,peer,phase='before_'+name)
  trial='public-'+uuid.uuid4().hex
  f=docs/'paired-reset.json.tmp';f.write_text(json.dumps({'trial':trial,'seed':seed,'advance':advance,'shift':threshold>0,'shift_after':threshold or 20}));f.replace(docs/'paired-reset.json')
  until=time.monotonic()+20
  while True:
   before=json.loads(receipt.read_text()) if receipt.exists() else {}
   if before.get('trial')==trial and before.get('foreground_active') and before.get('keyboard_did_show') and before.get('focus')=='a':break
   if time.monotonic()>until:
    last_setup={'phase':'reset','case':name,'receipt':before};save();raise RuntimeError('fixture reset did not converge; setup receipt retained')
   time.sleep(.1)
  active,_=r.drag.runner_call(a,'/wda/activeAppInfo');assert active['value']['bundleId']==bundle and active['value']['pid']==before['pid']
  if target=='field-multiline':
   found,_=r.drag.runner_call(a,'/element',{'using':'accessibility id','value':target});fid=found['value'].get('ELEMENT') or found['value'].get('element-6066-11e4-a52e-4f735466cecf');assert fid
   pending=True;r.drag.runner_call(a,'/element/'+fid+'/click',{});pending=False
   r.wait_for_native_idle(d,a,peer,phase='after_setup_click');before=json.loads(receipt.read_text());assert before['focus']=='multi'
  seen=call('phone_elements',{});result,_,tree=r.pair.payload(seen);assert not result.get('isError')
  index=next(i for i,x in enumerate(tree['elements']) if x.get('identifier')==target)
  args={'text':text,'clear':False,'observe':False} if kind=='type' else {'element':index,'snapshot':tree['snapshot'],'value':text,'observe':False}
  if recover:args['recover_focus_after_clear']=True
  current={'structured_mode':mode,'case':name,'trial':trial,'before':before,'text_scalars':len(text),'text_sha256':hashlib.sha256(text.encode()).hexdigest(),'kind':kind};save()
  if kind=='batch':
   args={'steps':[{'kind':'tap_locator','locator':{'identifier':'field-a','kind':'TextField'}}, {'kind':'set_value','element':index,'snapshot':tree['snapshot'],'value':text}, {'kind':'key','name':'return'}], 'observe':False}
  started=time.monotonic();pending=True;reply=call('phone_type' if kind=='type' else 'phone_run_steps' if kind=='batch' else 'phone_set_value',args);pending=False
  current.update(reply=reply,seconds=time.monotonic()-started);save()
  r.wait_for_native_idle(d,a,peer,phase='after_'+name)
  after=json.loads(receipt.read_text());current['readbacks']=[after];save();until=time.monotonic()+2
  while True:
   time.sleep(.2);fresh=json.loads(receipt.read_text());current['readbacks'].append(fresh);save()
   if after==fresh:break
   after=fresh
   if time.monotonic()>until:raise RuntimeError('App receipt did not stabilize; no next trial')
  current['after']=after;rows.append(current);current=None;save()
  _,_,body=r.pair.payload(reply);print(json.dumps({'case':name,'reply_keys':list(body),'fields':{k:x['characters'] for k,x in after['fields'].items()},'shift_trigger_length':after.get('shift_trigger_length')}),flush=True)
except BaseException as e:errors.append(repr(e));(a.out/'traceback.txt').write_text(traceback.format_exc())
finally:
 if peer:
  try:peer.close()
  except Exception as e:cleanup.append(repr(e))
 try:
  if pending:raise RuntimeError('uncertain MCP response; no replay or next trial')
  r.wait_for_native_idle(d,a,phase='before_cleanup')
  if installed:r.pair.fixture.command('xcrun','simctl','uninstall',a.udid,bundle,timeout=30)
 except Exception as e:cleanup.append(repr(e))
 save()
raise SystemExit(1 if errors or cleanup else 0)
