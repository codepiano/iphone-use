from pathlib import Path
import subprocess,json,hashlib,socket
p=Path(__file__).parent;r=Path('/tmp/iphone-use-runner-input-target-guard')
owned=[]
for n in ['local-owned-simulator','local-owned-recovery-simulator','local-owned-public-launch-simulator']:
 if (p/n).exists():owned.append((p/n).read_text().strip())
d=json.loads(subprocess.check_output(['xcrun','simctl','list','devices','--json']))
remaining=[x['udid'] for g in d['devices'].values() for x in g if x['udid'] in owned]
processes=[]
for line in subprocess.check_output(['ps','-axo','pid=,args='],text=True).splitlines():
 if '/instances/ax-public-local-01a16e44/' in line or '--instance ax-public-local-01a16e44' in line or any(u in line for u in owned):processes.append(int(line.strip().split()[0]))
ports={}
for port in [44331,8200]:
 s=socket.socket();s.settimeout(.3);ports[str(port)]=s.connect_ex(('127.0.0.1',port))==0;s.close()
source=json.loads((p/'source-current.json').read_text());bad=[n for n,h in source.items() if hashlib.sha256((r/n).read_bytes()).hexdigest()!=h]
assert not bad,bad
native={n:hashlib.sha256((r/'runner/IPhoneUseRunner/IPhoneUseRunnerUITests'/n).read_bytes()).hexdigest() for n in ['IPURBridge.h','IPURBridge.m','RunnerRoutes.swift']}
a={'owned_simulator_count':len(owned),'remaining_owned_simulators':remaining,'live_owned_service_pids':processes,'test_ports_listening':ports,'rust_source_files_matched':len(source),'product_native_source_sha256':native,'current_binary_files_present':{n:(r/'target/debug'/n).exists() for n in ['iphone-use','iphone-use-mcp']},'executed_binary_sha256':json.loads((p/'local-result-public-launch/result.json').read_text())['binary_sha256'],'physical_phone_operated':False}
(p/'cleanup-local.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps(a));assert not remaining and not processes
