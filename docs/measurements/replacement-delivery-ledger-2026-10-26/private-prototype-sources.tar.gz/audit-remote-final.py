from pathlib import Path
import hashlib,json,subprocess,re
r=Path('/private/tmp/iphone-use-paired-01a16e44-20261025/recovery-candidate-20261026');p=r/'ax-public-pipeline';owned=set()
for n in ['startup-failure.log','run.log']:
 f=p/n
 if f.exists():
  for l in f.read_text(errors='replace').splitlines():
   if l.startswith('Simulator: ax-public-pipeline-01a16e44'):
    m=re.search(r'[A-Fa-f0-9]{8}(?:-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}',l)
    if m:owned.add(m.group())
d=json.loads(subprocess.check_output(['/Applications/Xcode-27.0.app/Contents/Developer/usr/bin/simctl','list','devices','--json']))
remaining=[x['udid'] for g in d['devices'].values() for x in g if x['udid'] in owned]
live=[]
for l in subprocess.check_output(['ps','-axo','pid=,args='],text=True).splitlines():
 if '--instance ax-public-pipeline-01a16e44' in l or '/instances/ax-public-pipeline-01a16e44/' in l or any(u in l for u in owned):live.append(int(l.strip().split()[0]))
source={n:hashlib.sha256((r/'runner/IPhoneUseRunner/IPhoneUseRunnerUITests'/n).read_bytes()).hexdigest() for n in ['IPURBridge.h','IPURBridge.m','RunnerRoutes.swift']}
a={'owned_simulator_count':len(owned),'remaining_owned_simulators':remaining,'live_owned_service_pids':live,'native_source_sha256':source,'final_remote_rust_run_marker_present':(p/'rust-final-exit').exists()};print(json.dumps(a));assert not remaining and not live
