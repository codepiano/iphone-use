#!/bin/bash
set -euo pipefail
probe_work=/tmp/iphone-use-ax-public-pipeline-20261026
probe_root=/tmp/iphone-use-runner-input-target-guard
export DEVELOPER_DIR=/Applications/Xcode-27.2-beta2.app/Contents/Developer
export DO_NOT_TRACK=1
export IPHONE_USE_ANALYTICS=0
export IPHONE_USE_NO_UPDATE_CHECK=1
export IPHONE_USE_FLOWS_NO_AUTO_UPDATE=1
export SDKROOT="$(xcrun --sdk macosx --show-sdk-path)"
export XCODEBUILD="$probe_work/xcodebuild-limited"
export IPU_RUNNER_SRC="$probe_work/local-runner"
export IPU_PUBLIC_PROBE_ROOT="$probe_root"
probe_sim=
cleanup() {
 probe_result=$?
 if [ -n "$probe_sim" ]; then
  "$probe_root/target/debug/iphone-use" simulator stop "$probe_sim" --instance ax-public-local-01a16e44 --shutdown > "$probe_work/local-stop-recovery.log" 2>&1 || true
  xcrun simctl delete "$probe_sim" > "$probe_work/local-delete-recovery.log" 2>&1 || true
 fi
 echo "$probe_result" > "$probe_work/local-recovery-exit"
}
trap cleanup EXIT
python3 - <<'PYCHECK'
import json,subprocess
r=next(r for r in json.loads(subprocess.check_output(['xcrun','simctl','list','runtimes','--json']))['runtimes'] if r['identifier']=='com.apple.CoreSimulator.SimRuntime.iOS-27-2')
assert r['isAvailable'] and any(d['identifier']=='com.apple.CoreSimulator.SimDeviceType.iPhone-17' for d in r['supportedDeviceTypes'])
print('Verified iPhone17 / iOS27.2 runtime pair',flush=True)
PYCHECK
probe_sim=$(xcrun simctl create ax-public-local-01a16e44 com.apple.CoreSimulator.SimDeviceType.iPhone-17 com.apple.CoreSimulator.SimRuntime.iOS-27-2)
printf '%s\n' "$probe_sim" > "$probe_work/local-owned-recovery-simulator"
nice -n 15 taskpolicy -b "$probe_root/target/debug/iphone-use" simulator start "$probe_sim" --instance ax-public-local-01a16e44
python3 "$probe_work/probe.py" --runner-record "$HOME/.iphone-use/instances/ax-public-local-01a16e44/simulator.json" --out "$probe_work/local-result-recovery"
