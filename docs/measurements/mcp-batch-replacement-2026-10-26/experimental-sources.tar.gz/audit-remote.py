from pathlib import Path
import json,hashlib,subprocess,socket
r=Path('/private/tmp/iphone-use-paired-01a16e44-20261025/recovery-candidate-20261026');p=r/'launch-followup-20261026';owned=[]
for n in ['owned-simulator','owned-simulator2','public-owned-simulator','public-owned-simulator2','public-owned-simulator3','public-owned-simulator4']:
 if (p/n).exists():owned.append((p/n).read_text().strip())
d=json.loads(subprocess.check_output(['/Applications/Xcode-27.0.app/Contents/Developer/usr/bin/simctl','list','devices','--json']))
remaining=[x['udid'] for g in d['devices'].values() for x in g if x['udid'] in owned]
labels=['launch-followup-01a16e44','launch-followup2-01a16e44','launch-public-01a16e44','launch-public2-01a16e44','launch-public3-01a16e44','launch-public4-01a16e44'];live=[]
for line in subprocess.check_output(['ps','-axo','pid=,args='],text=True).splitlines():
 if any('--instance '+k in line or '/instances/'+k+'/' in line for k in labels) or any(u in line for u in owned):live.append(int(line.strip().split()[0]))
stock={n:hashlib.sha256((r/'runner/IPhoneUseRunner/IPhoneUseRunnerUITests'/n).read_bytes()).hexdigest() for n in ['IPURBridge.h','IPURBridge.m','RunnerRoutes.swift']};assert stock==json.loads((p/'native-stock.json').read_text())
a={'owned_simulators':len(owned),'remaining_owned_simulators':remaining,'live_owned_services':live,'product_native_source_sha256':stock,'physical_phone_operated':False};(p/'cleanup.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps(a));assert not remaining and not live
