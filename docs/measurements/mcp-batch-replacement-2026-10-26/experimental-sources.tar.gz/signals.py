import signal,json
print(json.dumps({'sigint_ignored':signal.getsignal(signal.SIGINT)==signal.SIG_IGN,'sigquit_ignored':signal.getsignal(signal.SIGQUIT)==signal.SIG_IGN}))
