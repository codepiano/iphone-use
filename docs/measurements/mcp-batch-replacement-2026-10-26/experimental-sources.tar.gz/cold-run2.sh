#!/bin/bash
set -euo pipefail
root=/private/tmp/iphone-use-paired-01a16e44-20261025/recovery-candidate-20261026
work="$root/launch-followup-20261026"
export PATH=/Users/leo/.cargo/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export DEVELOPER_DIR=/Applications/Xcode-27.0.app/Contents/Developer
export SDKROOT="$(xcrun --sdk macosx --show-sdk-path)"
export XCODEBUILD="$work/xcodebuild-compile-background"
export IPU_RUNNER_SRC="$root/runner"
export DO_NOT_TRACK=1 IPHONE_USE_ANALYTICS=0 IPHONE_USE_NO_UPDATE_CHECK=1 IPHONE_USE_FLOWS_NO_AUTO_UPDATE=1
cd "$root"
sim=
cleanup() {
 result=$?
 if [ -n "$sim" ]; then
  "$root/target/debug/iphone-use" simulator stop "$sim" --instance launch-followup2-01a16e44 --shutdown > "$work/stop2.log" 2>&1 || true
  xcrun simctl delete "$sim" > "$work/delete2.log" 2>&1 || true
 fi
 echo "$result" > "$work/cold-exit2"
}
trap cleanup EXIT
sim=$(xcrun simctl create launch-followup2-01a16e44 com.apple.CoreSimulator.SimDeviceType.iPhone-17 com.apple.CoreSimulator.SimRuntime.iOS-26-2)
printf '%s\n' "$sim" > "$work/owned-simulator2"
# Runtime inherits normal service priority. Only the compiler wrapper lowers QoS.
"$root/target/debug/iphone-use" simulator start "$sim" --instance launch-followup2-01a16e44
python3 "$work/cold.py" --record "$HOME/.iphone-use/instances/launch-followup2-01a16e44/simulator.json" --out "$work/cold-result2"
