#!/bin/bash
set -euo pipefail
root=/private/tmp/iphone-use-paired-01a16e44-20261025/recovery-candidate-20261026
work="$root/launch-followup-20261026"
export PATH=/Users/leo/.cargo/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export DEVELOPER_DIR=/Applications/Xcode-27.0.app/Contents/Developer
export SDKROOT="$(xcrun --sdk macosx --show-sdk-path)"
export XCODEBUILD="$work/xcodebuild-compile-background"
export IPU_RUNNER_SRC="$work/runner-private"
export DO_NOT_TRACK=1 IPHONE_USE_ANALYTICS=0 IPHONE_USE_NO_UPDATE_CHECK=1 IPHONE_USE_FLOWS_NO_AUTO_UPDATE=1
cd "$root"
python3 - <<'PY'
from pathlib import Path
import shutil,hashlib,json
p=Path('launch-followup-20261026');r=Path('runner');dst=p/'runner-private';shutil.copytree(r,dst,ignore=shutil.ignore_patterns('build','DerivedData*','xcuserdata'))
original={}
for n in ['IPURBridge.h','IPURBridge.m','RunnerRoutes.swift']:
 rel=Path('IPhoneUseRunner/IPhoneUseRunnerUITests')/n;original[n]=hashlib.sha256((r/rel).read_bytes()).hexdigest();shutil.copy2(p/n,dst/rel)
backup=p/'scripts-before';backup.mkdir()
for n in ['test-replacement-recovery-simulator.py','test-replacement-recovery-verdict.py','test-drag-simulator.py']:
 shutil.copy2(Path('scripts')/n,backup/n);shutil.copy2(p/n,Path('scripts')/n)
(p/'native-stock.json').write_text(json.dumps(original,indent=2))
PY
sim=
cleanup() {
 result=$?
 if [ -n "$sim" ]; then
  "$root/target/debug/iphone-use" simulator stop "$sim" --instance launch-public-01a16e44 --shutdown > "$work/public-stop.log" 2>&1 || true
  xcrun simctl delete "$sim" > "$work/public-delete.log" 2>&1 || true
 fi
 echo "$result" > "$work/public-exit"
}
trap cleanup EXIT
sim=$(xcrun simctl create launch-public-01a16e44 com.apple.CoreSimulator.SimDeviceType.iPhone-17 com.apple.CoreSimulator.SimRuntime.iOS-26-2)
printf '%s\n' "$sim" > "$work/public-owned-simulator"
"$root/target/debug/iphone-use" simulator start "$sim" --instance launch-public-01a16e44
python3 "$work/probe.py" --runner-record "$HOME/.iphone-use/instances/launch-public-01a16e44/simulator.json" --out "$work/public-result"
