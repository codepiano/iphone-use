from pathlib import Path
import argparse,importlib.util,sys,os,json,time,hashlib,traceback
P=Path(__file__).resolve().parent;ROOT=P.parent;sys.path.insert(0,str(ROOT/'scripts'))
spec=importlib.util.spec_from_file_location('recovery',ROOT/'scripts/test-replacement-recovery-simulator.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
p=argparse.ArgumentParser();p.add_argument('--record',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.runner_record=a.record;a.out.mkdir(mode=0o700,exist_ok=False)
x=json.loads(a.record.read_text());a.udid=x['udid'];a.owner='cold-launch-followup';a.base='http://127.0.0.1:'+str(x['daemon_port']);d=r.drag.Daemon(a.base,a.owner)
res={'scope':'Owned Simulator cold launch only; no text input, no model session','errors':[],'cleanup_errors':[]};peer=None;installed=False;pending=False
bundle='com.leeguoo.iphone-use.launch-followup'
def save():(a.out/'result.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n')
def status():
 s=d.call('/agent/status');assert s.get('target')=='simulator' and s.get('udid','').lower()==a.udid.lower() and s.get('owner') in (None,a.owner) and s.get('screen_private_secs',0)==0 and not s.get('human_handoff'),'scope/private/owner changed';return s
try:
 until=time.monotonic()+60
 while not status().get('drivable'):
  assert time.monotonic()<until,'initial readiness did not settle';time.sleep(.2)
 d.call('/agent/hold',{'secs':300});d.require_simulator(a.udid)
 r.pair.fixture.FIXTURE=(P/'fixture.swift').read_text();r.pair.fixture.BUNDLE=bundle
 old=r.subprocess.run(['xcrun','simctl','get_app_container',a.udid,bundle,'data'],capture_output=True,timeout=20);assert old.returncode!=0,'refuse existing fixture'
 app=r.pair.fixture.build_fixture(a.out);r.pair.fixture.command('xcrun','simctl','install',a.udid,app);installed=True
 docs=Path(r.pair.fixture.command('xcrun','simctl','get_app_container',a.udid,bundle,'data',timeout=30))/'Documents';receipt=docs/'paired-state.json'
 env={k:v for k,v in os.environ.items() if not k.startswith(('IPHONE_USE_','IPU_','PHONE_REMOTE_','TEST_RUNNER_'))};env.update(DO_NOT_TRACK='1',IPHONE_USE_URL=a.base,IPHONE_USE_OWNER=a.owner,IPHONE_USE_MCP_PREWARM='0',IPHONE_USE_MCP_STRUCTURED='full',IPHONE_USE_STATE_DIR=str(a.out/'mcp-state'),IPHONE_USE_FLOWS_NO_AUTO_UPDATE='1')
 peer=r.pair.Peer([str(ROOT/'target/debug/iphone-use-mcp')],env,a.out/'mcp.log');listing=peer.request('tools/list',{});res['tools']=len(listing['result']['tools'])
 started=time.monotonic();pending=True;reply=peer.request('tools/call',{'name':'phone_run_steps','arguments':{'steps':[{'kind':'launch_app','bundle':bundle}],'observe':False}},timeout=85);pending=False
 result,_,body=r.pair.payload(reply);res.update(reply=reply,public_launch_seconds=time.monotonic()-started,api_ack=body.get('ok') is True and result.get('isError') is not True);save()
 until=time.monotonic()+15;polls=[]
 while True:
  s=status();polls.append({k:s.get(k) for k in ['drivable','device_state','runner','runner_locked','reconnecting','released']});res['post_reply_status']=polls;save()
  if s.get('drivable') is True:
   meta,_=r.drag.runner_call(a,'/status')
   if meta.get('value',{}).get('busy') is False:break
  assert time.monotonic()<until,'post-reply metadata did not settle; no replay'
  time.sleep(.2)
 until=time.monotonic()+10
 while True:
  status();seen=json.loads(receipt.read_text()) if receipt.exists() else {};res['app_receipt']=seen;save()
  if seen.get('foreground_active'):break
  assert time.monotonic()<until,'owned App was not independently foreground';time.sleep(.2)
 active,_=r.drag.runner_call(a,'/wda/activeAppInfo');res['foreground_matches']=active.get('value',{}).get('bundleId')==bundle and active['value'].get('pid')==seen['pid'];res['launch_verified']=res['api_ack'] and res['foreground_matches'];save()
except BaseException as e:res['errors'].append(repr(e));(a.out/'traceback.txt').write_text(traceback.format_exc())
finally:
 if peer:
  try:
   if peer.pending is None:peer.close()
   else:r.pair.stop(peer.process)
  except Exception as e:res['cleanup_errors'].append(repr(e))
 try:
  if installed:r.pair.fixture.command('xcrun','simctl','uninstall',a.udid,bundle,timeout=30)
 except Exception as e:res['cleanup_errors'].append(repr(e))
 res['pending']=pending;res['input_actions_sent']=0;res['binary_sha256']={n:hashlib.sha256((ROOT/'target/debug'/n).read_bytes()).hexdigest() for n in ['iphone-use','iphone-use-mcp']};save()
print(json.dumps({k:res.get(k) for k in ['public_launch_seconds','api_ack','foreground_matches','launch_verified','errors','cleanup_errors']}),flush=True)
raise SystemExit(1 if res['errors'] or res['cleanup_errors'] else 0)
